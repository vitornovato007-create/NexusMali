# NexusMali v0.2 — Mali-G76 / Exynos 9820

This release is a source-level NexusMali integration based on the supplied
Mesa 26.3.0-devel PanVK Bifrost/kbase tree.

## Target

- Mali-G76 MP12 (Bifrost v7)
- Exynos 9820 / Galaxy S10 family
- Stock Samsung kbase: `/dev/mali0`
- Android 12 runtime, Android API 31 build target
- Winlator/DXVK and Android Vulkan applications

## What is deliberately preserved

The v0.2 source keeps the upstream PanVK memory, Android gralloc/AHardwareBuffer,
swapchain and kbase implementations intact. These paths are already specifically
adapted for Bifrost/kbase and are safer than speculative binary patches.

## Known v0.1 failure modes this base is intended to avoid

1. G52 binary masquerading as G76: removed. v0.2 is built from the G76-capable
   Bifrost/kbase source tree.
2. RAM runaway: the source uses native kbase BO allocation/import/free paths and
   AHardwareBuffer lifetime management rather than the old G52 binary.
3. Black presentation: Android gralloc, native-buffer, AHardwareBuffer, swapchain
   and kbase acquire-fence paths are present in the source.
4. Extension inflation: extensions are exposed from PanVK's actual per-architecture
   implementation rather than being added merely to increase the extension count.

## Important

This archive is the **v0.2 source release**. A trustworthy native `libvulkan_panfrost.so`
requires an Android NDK/LLVM/Meson build environment. No prebuilt binary is relabeled as
v0.2 here; that would repeat the v0.1 mistake.

Build with:

    ./build.sh /path/to/android-ndk

The resulting package is written to `dist/`.

## Runtime test order

1. Vulkan loader/device creation
2. simple Vulkan triangle
3. swapchain/present
4. Hades / MegaBonk in Winlator
5. God Hand / Incredible Hulk / Devil May Cry in ARMSX2

For Winlator, verify the loaded library through `/proc/<pid>/maps` instead of relying only
on the GPU name shown in the UI.
