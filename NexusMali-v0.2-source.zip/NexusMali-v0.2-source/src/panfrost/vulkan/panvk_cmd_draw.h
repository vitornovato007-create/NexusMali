/*
 * Copyright © 2024 Collabora Ltd.
 * SPDX-License-Identifier: MIT
 */

#ifndef PANVK_CMD_DRAW_H
#define PANVK_CMD_DRAW_H

#ifndef PAN_ARCH
#error "PAN_ARCH must be defined"
#endif

#include "panvk_blend.h"
#include "panvk_cmd_desc_state.h"
#include "panvk_cmd_query.h"
#include "panvk_entrypoints.h"
#include "panvk_image.h"
#include "panvk_image_view.h"
#include "panvk_physical_device.h"
#include "panvk_shader.h"

#include "vk_command_buffer.h"
#include "vk_format.h"
#include "vk_meta.h"
#include "util/u_tristate.h"

#include "pan_fb.h"
#include "pan_props.h"

#define MAX_VBS 16

#if PAN_ARCH < 10
#define MAX_FRAMEBUFFER_DIMENSION (1 << 14)
#elif PAN_ARCH < 11
#define MAX_FRAMEBUFFER_DIMENSION (1 << 15)
#else
#define MAX_FRAMEBUFFER_DIMENSION (1 << 16)
#endif

#define MAX_FRAMEBUFFER_LAYERS 256

struct panvk_cmd_buffer;

struct panvk_attrib_buf {
   uint64_t address;
   unsigned size;
};

struct panvk_resolve_attachment {
   VkResolveModeFlagBits mode;
   struct panvk_image_view *dst_iview;
};

struct panvk_rendering_state {
   VkRenderingFlags flags;
   uint32_t layer_count;
   uint32_t view_mask;
   enum u_tristate first_provoking_vertex;

   enum vk_rp_attachment_flags bound_attachments;
   struct {
      struct panvk_image_view *iviews[MAX_RTS];
      /* If non-null, preload_iviews[i] overrides iviews[i] for preloads. */
      struct panvk_image_view *preload_iviews[MAX_RTS];
      VkFormat fmts[MAX_RTS];
      uint8_t samples[MAX_RTS];
      struct panvk_resolve_attachment resolve[MAX_RTS];
   } color_attachments;

   struct {
      struct panvk_image_view *iview;
      /* If non-null, preload_iview overrides iview for preloads. */
      struct panvk_image_view *preload_iview;
      VkFormat fmt;
      struct panvk_resolve_attachment resolve;
   } z_attachment, s_attachment;

   /* Used for separate Z/S images */
   struct {
      struct pan_image_view load, spill, store, resolve;
   } z_pview, s_pview;

   struct {
      struct pan_fb_layout layout;
      struct pan_fb_load load;
      struct pan_fb_resolve resolve;
      struct pan_fb_store store;
      struct {
         struct pan_fb_load load;
         struct pan_fb_store store;
      } spill;

      /* nr_samples to be used before framebuffer / tiler descriptor are emitted */
      uint32_t nr_samples;

#if PAN_ARCH < 9
      uint32_t bo_count;
      struct pan_kmod_bo *bos[(MAX_RTS * PANVK_MAX_PLANES) + 2];
      bool needs_load;
      bool needs_store;
#endif
   } fb;

#if PAN_ARCH >= 10
   struct pan_ptr fbds;
   uint64_t tiler;

   /* When a secondary command buffer has to flush draws, it disturbs the
    * inherited context, and the primary command buffer needs to know. */
   bool invalidate_inherited_ctx;

   /* True if the last render pass was suspended. */
   bool suspended;

   /* Blocks that can patch to flip the provoking vertex mode if we need to
    * emit FBDs/TDs before we know which mode the application is using */
   struct cs_maybe *maybe_set_tds_provoking_vertex;
   struct cs_maybe *maybe_set_fbds_provoking_vertex;

   struct {
      /* != 0 if the render pass contains one or more occlusion queries to
       * signal. */
      uint64_t chain;

      /* Point to the syncobj of the last occlusion query that was passed
       * to a draw. */
      uint64_t last;
   } oq;

   struct {
      uint64_t fbds[3];
   } ir;
#endif
};

enum panvk_cmd_graphics_dirty_state {
   PANVK_CMD_GRAPHICS_DIRTY_BASE_INSTANCE,
   PANVK_CMD_GRAPHICS_DIRTY_VS,
   PANVK_CMD_GRAPHICS_DIRTY_FS,
   PANVK_CMD_GRAPHICS_DIRTY_VB,
   PANVK_CMD_GRAPHICS_DIRTY_OQ,
   PANVK_CMD_GRAPHICS_DIRTY_DESC_STATE,
   PANVK_CMD_GRAPHICS_DIRTY_RENDER_STATE,
   PANVK_CMD_GRAPHICS_DIRTY_VS_PUSH_UNIFORMS,
   PANVK_CMD_GRAPHICS_DIRTY_FS_PUSH_UNIFORMS,
   PANVK_CMD_GRAPHICS_DIRTY_IDVS,
   PANVK_CMD_GRAPHICS_DIRTY_GS,
   PANVK_CMD_GRAPHICS_DIRTY_GS_PUSH_UNIFORMS,
   PANVK_CMD_GRAPHICS_DIRTY_STATE_COUNT,
};

struct panvk_cmd_graphics_state {
   struct panvk_descriptor_state desc_state;

   struct {
      struct vk_vertex_input_state vi;
      struct vk_sample_locations_state sl;
   } dynamic;

   struct panvk_occlusion_query_state occlusion_query;
#if PAN_ARCH >= 10
   struct panvk_prims_generated_query_state prims_generated_query;
#endif
   struct panvk_graphics_sysvals sysvals;

#if PAN_ARCH < 9
   struct panvk_shader_link link;
#endif

   struct {
      const struct panvk_shader *shader;
      struct panvk_shader_desc_state desc;
      uint64_t blend_descs[MAX_RTS];
      uint64_t push_uniforms;
      bool required;
#if PAN_ARCH < 9
      uint64_t rsd;
#endif
   } fs;

   struct {
      enum mesa_prim prim;
      bool restart;
   } idvs;

#if PAN_ARCH < 9
   /* Geometry shaders are emulated by a compute job between the vertex and tiler jobs; see
    * panvk_nir_lower_gs.c. The buffers are the ones that job writes and the tiler then reads. */
   struct {
      /* The geometry shader that runs; app_shader is the one bound (see panvk_select_gs). */
      const struct panvk_shader *shader;
      const struct panvk_shader *app_shader;
      struct panvk_shader_desc_state desc;
      uint64_t push_uniforms;
      uint64_t out_pos;
      uint64_t out_general;
      uint64_t out_index;
      uint64_t in_general;
      uint32_t in_general_stride;
      uint64_t in_offsets;
      uint64_t out_offsets;
      uint32_t out_general_stride;
      uint32_t out_vertex_count;
      uint32_t out_index_count;
      enum mesa_prim out_prim;
      /* PANVK_GS_CPUFILL: the tiler's input was authored by the CPU, so the emulation job is
       * not run and culling is off. A bisect, not a feature. */
      bool cpufill;
      /* PANVK_GS_CPUFILL=2: as above, but ONLY DRAW.position is redirected -- index buffer,
       * draw mode, instance fields and invocation stay exactly as the working path emits them.
       * Isolates "the tiler will not read positions from here" from everything else. */
      bool posonly;
      /* PANVK_GS_CPUFILL=3: CPU-fill the buffers AND still run the emulation job. If the job's
       * stores land they overwrite the CPU triangle with the passthrough one, so the two are
       * told apart by pixel count alone -- no instrumentation inside the shader. */
      bool keepjob;
      /* PANVK_GS_INFROMCPU: in_pos points at a CPU-written triangle instead of the vertex
       * shader's varying buffer. Separates "a global load in this job cannot read memory" from
       * "it cannot read what the VERTEX JOB just wrote". */
      uint64_t in_pos_override;
      /* Transform feedback: the counts and staging records the emulation fills when the draw is
       * capturing (see panvk_gs_push). */
      uint64_t xfb_counts;
      uint64_t xfb_staging;
      uint32_t xfb_invocations;
      /* geometryStreams, see panvk_gs_push::xfb_stream_*. */
      uint64_t xfb_stream_index;
      uint32_t xfb_stream_slots;
      uint32_t xfb_stream_idx;
      /* gl_ViewportIndex: the per-viewport transform table (panvk_gs_push::viewports). */
      uint64_t viewports;
   } gs;

   /* Tessellation. The tess eval shader runs through the geometry shader emulation
    * (panvk_select_gs); the tess control shader and the tessellator are compute jobs in front of
    * it (emit_tess_jobs). */
   struct {
      const struct panvk_shader *tcs;
      const struct panvk_shader *tes;
   } tess;

   /* VK_EXT_transform_feedback, captured from the geometry shader emulation. The write offsets
    * live in GPU memory because they advance on the GPU, draw by draw: each capturing draw reads
    * `offsets` and leaves a fresh slot behind for the next. last_job orders the capture jobs of
    * the current batch; closing the batch resets it. */
   struct {
      uint64_t addr[4];
      uint32_t size[4];
      bool active;
      uint64_t offsets;
      unsigned last_job;
   } xfb;
#endif

   struct {
      const struct panvk_shader *shader;
      struct panvk_shader_desc_state desc;
      uint64_t push_uniforms;
#if PAN_ARCH < 9
      uint64_t attribs;
      uint64_t attrib_bufs;
      uint64_t indirect_attribs_infos;
      uint64_t indirect_attrib_bufs_infos;
      uint64_t indirect_varying_bufs_infos;
      bool previous_draw_was_indirect;
#else
      /* The number of times desc is repeated.  Zero means that it is not
       * repeated but also that it's re-usable across draws and we're not
       * allowed to patch it from the CSF.
       */
      uint32_t desc_repeat_count;
#endif
   } vs;

   struct {
      struct panvk_attrib_buf bufs[MAX_VBS];
      unsigned count;
   } vb;

#if PAN_ARCH >= 10
   struct {
      uint32_t base_instance;
      uint32_t attribs_changing_on_base_instance;
   } vi;
#endif

   /* Index buffer */
   struct {
      uint64_t dev_addr;
      uint64_t size;
      uint8_t index_size;
      /* The indices can be read on the CPU at record time: the buffer's GPU address is also its
       * CPU address (kbase SAME_VA), and its usage lets nothing but the CPU write it. */
      bool cpu_readable;
   } ib;

   struct {
      struct panvk_blend_info info;
   } cb;

   struct panvk_rendering_state render;

   bool vk_meta;

#if PAN_ARCH < 9
   uint64_t vpd;
#endif

#if PAN_ARCH >= 10
   uint64_t tsd;
#endif

   BITSET_DECLARE(dirty, PANVK_CMD_GRAPHICS_DIRTY_STATE_COUNT);
};

#define dyn_gfx_state_dirty(__cmdbuf, __name)                                  \
   BITSET_TEST((__cmdbuf)->vk.dynamic_graphics_state.dirty,                    \
               MESA_VK_DYNAMIC_##__name)

#define gfx_state_dirty(__cmdbuf, __name)                                      \
   BITSET_TEST((__cmdbuf)->state.gfx.dirty, PANVK_CMD_GRAPHICS_DIRTY_##__name)

#define gfx_state_set_dirty(__cmdbuf, __name)                                  \
   BITSET_SET((__cmdbuf)->state.gfx.dirty, PANVK_CMD_GRAPHICS_DIRTY_##__name)

#define gfx_state_clear_all_dirty(__cmdbuf)                                    \
   BITSET_ZERO((__cmdbuf)->state.gfx.dirty)

#define gfx_state_set_all_dirty(__cmdbuf)                                      \
   BITSET_ONES((__cmdbuf)->state.gfx.dirty)

#define set_gfx_sysval(__cmdbuf, __dirty, __name, __val)                       \
   do {                                                                        \
      struct panvk_graphics_sysvals __new_sysval;                              \
      __new_sysval.__name = __val;                                             \
      if (memcmp(&(__cmdbuf)->state.gfx.sysvals.__name, &__new_sysval.__name,  \
                 sizeof(__new_sysval.__name))) {                               \
         (__cmdbuf)->state.gfx.sysvals.__name = __new_sysval.__name;           \
         BITSET_SET_RANGE(__dirty, sysval_fau_start(graphics, __name),         \
                          sysval_fau_end(graphics, __name));                   \
      }                                                                        \
   } while (0)

#if PAN_ARCH >= 10 && PAN_ARCH < 14
struct panvk_device_draw_context {
   struct panvk_priv_bo *fns_bo;
   uint64_t fn_set_fbds_provoking_vertex_stride;
};
#endif

static inline void
panvk_depth_range(const struct panvk_cmd_graphics_state *state,
                  const struct vk_viewport_state *vp,
                  float *z_min, float *z_max)
{
   if (vp->depth_clamp_mode == VK_DEPTH_CLAMP_MODE_USER_DEFINED_RANGE_EXT) {
      *z_min = vp->depth_clamp_range.minDepthClamp;
      *z_max = vp->depth_clamp_range.maxDepthClamp;
      return;
   }

   float a = vp->depth_clip_negative_one_to_one ?
      state->sysvals.viewport.offset.z - state->sysvals.viewport.scale.z :
      state->sysvals.viewport.offset.z;
   float b = state->sysvals.viewport.offset.z + state->sysvals.viewport.scale.z;
   *z_min = MIN2(a, b);
   *z_max = MAX2(a, b);
}

static inline uint32_t
panvk_select_tiler_hierarchy_mask(const struct panvk_physical_device *phys_dev,
                                  const struct panvk_cmd_graphics_state *state,
                                  unsigned bin_ptr_mem_budget)
{
   struct pan_tiler_features tiler_features =
      pan_query_tiler_features(&phys_dev->kmod.dev->props);

   uint32_t hierarchy_mask = GENX(pan_select_tiler_hierarchy_mask)(
      state->render.fb.layout.width_px, state->render.fb.layout.height_px,
      tiler_features.max_levels, state->render.fb.layout.tile_size_px,
      bin_ptr_mem_budget);

   return hierarchy_mask;
}

static inline bool
fs_required(const struct panvk_cmd_graphics_state *state,
            const struct vk_dynamic_graphics_state *dyn_state)
{
   const struct panvk_shader_variant *fs =
      panvk_shader_only_variant(state->fs.shader);
   const struct pan_shader_info *fs_info = fs ? &fs->info : NULL;
   const struct vk_color_blend_state *cb = &dyn_state->cb;
   const struct vk_rasterization_state *rs = &dyn_state->rs;

   if (rs->rasterizer_discard_enable || !fs_info)
      return false;

   /* If we generally have side effects */
   if (fs_info->fs.sidefx)
      return true;

   /* If colour is written we need to execute */
   for (unsigned i = 0; i < cb->attachment_count; ++i) {
      if ((cb->color_write_enables & BITFIELD_BIT(i)) &&
          cb->attachments[i].write_mask)
         return true;
   }

   /* If alpha-to-coverage is enabled, we need to run the fragment shader even
    * if we don't have a color attachment, so depth/stencil updates can be
    * discarded if alpha, and thus coverage, is 0. */
   if (dyn_state->ms.alpha_to_coverage_enable)
      return true;

   /* If the sample mask is updated, we need to run the fragment shader,
    * otherwise the fixed-function depth/stencil results will apply to all
    * samples. */
   if (fs_info->outputs_written & BITFIELD64_BIT(FRAG_RESULT_SAMPLE_MASK))
      return true;

   /* If depth is written and not implied we need to execute.
    * TODO: Predicate on Z/S writes being enabled */
   return (fs_info->fs.writes_depth || fs_info->fs.writes_stencil);
}

static inline bool
cached_fs_required(ASSERTED const struct panvk_cmd_graphics_state *state,
                   ASSERTED const struct vk_dynamic_graphics_state *dyn_state,
                   bool cached_value)
{
   /* Make sure the cached value was properly initialized. */
   assert(fs_required(state, dyn_state) == cached_value);
   return cached_value;
}

#define get_fs(__cmdbuf)                                                       \
   (cached_fs_required(&(__cmdbuf)->state.gfx,                                 \
                       &(__cmdbuf)->vk.dynamic_graphics_state,                 \
                       (__cmdbuf)->state.gfx.fs.required)                      \
       ? (__cmdbuf)->state.gfx.fs.shader                                       \
       : NULL)

/* Anything that might change the value returned by get_fs() makes users of the
 * fragment shader dirty, because not using the fragment shader (when
 * fs_required() returns false) impacts various other things, like VS -> FS
 * linking in the JM backend, or the update of the fragment shader pointer in
 * the CSF backend. Call gfx_state_dirty(cmdbuf, FS) if you only care about
 * fragment shader updates. */

#define fs_user_dirty(__cmdbuf)                                                \
   (gfx_state_dirty(cmdbuf, FS) ||                                             \
    dyn_gfx_state_dirty(cmdbuf, RS_RASTERIZER_DISCARD_ENABLE) ||               \
    dyn_gfx_state_dirty(cmdbuf, CB_ATTACHMENT_COUNT) ||                        \
    dyn_gfx_state_dirty(cmdbuf, CB_COLOR_WRITE_ENABLES) ||                     \
    dyn_gfx_state_dirty(cmdbuf, CB_WRITE_MASKS) ||                             \
    dyn_gfx_state_dirty(cmdbuf, MS_ALPHA_TO_COVERAGE_ENABLE))

/* After a draw, all dirty flags are cleared except the FS dirty flag which
 * needs to be set again if the draw didn't use the fragment shader. */

#define clear_dirty_after_draw(__cmdbuf)                                       \
   do {                                                                        \
      bool __set_fs_dirty =                                                    \
         (__cmdbuf)->state.gfx.fs.shader != get_fs(__cmdbuf);                  \
      bool __set_fs_push_dirty =                                               \
         __set_fs_dirty && gfx_state_dirty(__cmdbuf, FS_PUSH_UNIFORMS);        \
      vk_dynamic_graphics_state_clear_dirty(                                   \
         &(__cmdbuf)->vk.dynamic_graphics_state);                              \
      gfx_state_clear_all_dirty(__cmdbuf);                                     \
      if (__set_fs_dirty)                                                      \
         gfx_state_set_dirty(__cmdbuf, FS);                                    \
      if (__set_fs_push_dirty)                                                 \
         gfx_state_set_dirty(__cmdbuf, FS_PUSH_UNIFORMS);                      \
   } while (0)

#if PAN_ARCH >= 10 && PAN_ARCH < 14
VkResult
panvk_per_arch(device_draw_context_init)(struct panvk_device *dev);

void
panvk_per_arch(device_draw_context_cleanup)(struct panvk_device *dev);
#endif

void
panvk_per_arch(cmd_init_render_state)(struct panvk_cmd_buffer *cmdbuf,
                                      const VkRenderingInfo *pRenderingInfo);

void panvk_per_arch(cmd_select_tile_size)(struct panvk_cmd_buffer *cmdbuf);

struct panvk_draw_info {
   struct {
      uint64_t buffer_dev_addr;
      uint64_t buffer_size;
      uint32_t index_size;
      uint32_t offset;
      bool restart_enable;
   } index;

   struct {
#if PAN_ARCH < 9
      int32_t raw_offset;
#endif
      int32_t base;
      uint32_t count;
   } vertex;

   struct {
      int32_t base;
      uint32_t count;
   } instance;

   struct {
      uint64_t buffer_dev_addr;
      uint64_t count_buffer_dev_addr;
      uint32_t draw_count;
      uint32_t stride;
   } indirect;

   enum mesa_prim prim;

#if PAN_ARCH < 9
   uint32_t layer_id;
#endif
};

#define panvk_draw_info_index(__cmdbuf, __offset) {                            \
   .buffer_dev_addr = (__cmdbuf)->state.gfx.ib.dev_addr,                       \
   .buffer_size = (__cmdbuf)->state.gfx.ib.size,                               \
   .index_size = (__cmdbuf)->state.gfx.ib.index_size,                          \
   .offset = (__offset),                                                       \
   .restart_enable =                                                           \
      (__cmdbuf)->vk.dynamic_graphics_state.ia.primitive_restart_enable,       \
}

#define panvk_get_client_prim(__cmdbuf) vk_topology_to_mesa(                   \
      (__cmdbuf)->vk.dynamic_graphics_state.ia.primitive_topology)

void
panvk_per_arch(cmd_prepare_draw_sysvals)(struct panvk_cmd_buffer *cmdbuf,
                                         const struct panvk_draw_info *info,
                                         const struct panvk_shader_variant *fs);

static inline uint32_t
color_attachment_written_mask(
   const struct panvk_shader_variant *fs,
   const struct vk_color_attachment_location_state *cal)
{
   uint32_t written_by_shader =
      (fs->info.outputs_written >> FRAG_RESULT_DATA0) & BITFIELD_MASK(8);
   uint32_t catt_written_mask = 0;

   for (uint32_t i = 0; i < MAX_RTS; i++) {
      if (cal->color_map[i] == MESA_VK_ATTACHMENT_UNUSED)
         continue;

      uint32_t shader_rt = cal->color_map[i];

      if (written_by_shader & BITFIELD_BIT(shader_rt))
         catt_written_mask |= BITFIELD_BIT(i);
   }

   return catt_written_mask;
}

static inline uint32_t
color_attachment_read_mask(const struct panvk_shader_variant *fs,
                           const struct vk_input_attachment_location_state *ial,
                           uint8_t color_attachment_mask)
{
   uint32_t color_attachment_count =
      ial->color_attachment_count == MESA_VK_COLOR_ATTACHMENT_COUNT_UNKNOWN
         ? util_last_bit(color_attachment_mask)
         : ial->color_attachment_count;
   uint32_t catt_read_mask = 0;

   for (uint32_t i = 0; i < color_attachment_count; i++) {
      if (ial->color_map[i] == MESA_VK_ATTACHMENT_UNUSED)
         continue;

      uint32_t catt_idx = ial->color_map[i] + 1;
      if (fs->fs.input_attachment_read & BITFIELD_BIT(catt_idx)) {
         assert(color_attachment_mask & BITFIELD_BIT(i));
         catt_read_mask |= BITFIELD_BIT(i);
      }
   }

   catt_read_mask |= fs->fs.tile_image_color_read & color_attachment_mask;

   return catt_read_mask;
}

static inline bool
z_attachment_read(const struct panvk_shader_variant *fs,
                  const struct vk_input_attachment_location_state *ial)
{
   uint32_t depth_mask = ial->depth_att == MESA_VK_ATTACHMENT_NO_INDEX
                            ? BITFIELD_BIT(0)
                         : ial->depth_att != MESA_VK_ATTACHMENT_UNUSED
                            ? BITFIELD_BIT(ial->depth_att + 1)
                            : 0;
   return (depth_mask & fs->fs.input_attachment_read) ||
          fs->fs.tile_image_z_read;
}

static inline bool
s_attachment_read(const struct panvk_shader_variant *fs,
                  const struct vk_input_attachment_location_state *ial)
{
   uint32_t stencil_mask = ial->stencil_att == MESA_VK_ATTACHMENT_NO_INDEX
                              ? BITFIELD_BIT(0)
                           : ial->stencil_att != MESA_VK_ATTACHMENT_UNUSED
                              ? BITFIELD_BIT(ial->stencil_att + 1)
                              : 0;

   return (stencil_mask & fs->fs.input_attachment_read) ||
          fs->fs.tile_image_s_read;
}

#if PAN_ARCH >= 10
void panvk_per_arch(cmd_draw_rects)(struct vk_command_buffer *cmd,
                                    struct vk_meta_device *meta,
                                    uint32_t rect_count,
                                    const struct vk_meta_rect *rects);

void panvk_per_arch(cmd_draw_volume)(struct vk_command_buffer *cmd,
                                     struct vk_meta_device *meta,
                                     const struct vk_meta_rect *rect,
                                     uint32_t layer_count);
#endif

#endif
