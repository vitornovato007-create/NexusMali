/*
 * Copyright © 2021 Collabora Ltd.
 *
 * Derived from tu_device.c which is:
 * Copyright © 2016 Red Hat.
 * Copyright © 2016 Bas Nieuwenhuizen
 * Copyright © 2015 Intel Corporation
 *
 * SPDX-License-Identifier: MIT
 */

#include <sys/sysmacros.h>

#include "git_sha1.h"

#include "vk_android.h"
#include "vk_device.h"
#include "vk_limits.h"
#include "vk_shader_module.h"

#include "panvk_instance.h"
#include "panvk_buffer.h"
#include "panvk_cmd_draw.h"
#include "panvk_gs.h"
#include "panvk_descriptor_set_layout.h"
#include "panvk_physical_device.h"
#include "panvk_wsi.h"

#include "pan_format.h"
#include "pan_props.h"

/* We reserve one ubo for push constant, one for sysvals and one per-set for the
 * descriptor metadata  */
#define RESERVED_UBO_COUNT                   6
#define MAX_INLINE_UNIFORM_BLOCK_DESCRIPTORS (32 - RESERVED_UBO_COUNT)

void
panvk_per_arch(get_physical_device_extensions)(
   const struct panvk_physical_device *device,
   const struct panvk_instance *instance,
   struct vk_device_extension_table *ext)
{
   bool has_gralloc = vk_android_get_ugralloc() != NULL;

   *ext = (struct vk_device_extension_table){
      .KHR_8bit_storage = true,
      .KHR_16bit_storage = true,
      .KHR_shader_atomic_int64 = PAN_ARCH >= 9,
      .KHR_bind_memory2 = true,
      .KHR_buffer_device_address = true,
      .KHR_calibrated_timestamps =
         device->kmod.dev->props.gpu_can_query_timestamp,
      .KHR_compute_shader_derivatives = PAN_ARCH >= 9,
      .KHR_cooperative_matrix = PAN_ARCH >= 11,
      .KHR_copy_commands2 = true,
      .KHR_copy_memory_indirect = PAN_ARCH >= 10,
      .KHR_create_renderpass2 = true,
      .KHR_dedicated_allocation = true,
      .KHR_descriptor_update_template = true,
      .KHR_depth_clamp_zero_one = true,
      .KHR_depth_stencil_resolve = true,
      .KHR_device_group = true,
      .KHR_draw_indirect_count = PAN_ARCH >= 10,
      .KHR_driver_properties = true,
      .KHR_dynamic_rendering = true,
      .KHR_dynamic_rendering_local_read = true,
      .KHR_external_fence = true,
      .KHR_external_fence_fd = true,
      .KHR_external_memory = true,
      .KHR_external_memory_fd = true,
      .KHR_external_semaphore = true,
      .KHR_external_semaphore_fd = true,
      .KHR_format_feature_flags2 = true,
      .KHR_get_memory_requirements2 = true,
      .KHR_global_priority = true,
      .KHR_image_format_list = true,
      .KHR_imageless_framebuffer = true,
      .KHR_index_type_uint8 = true,
      .KHR_internally_synchronized_queues = true,
      .KHR_line_rasterization = true,
      .KHR_load_store_op_none = true,
      .KHR_maintenance1 = true,
      .KHR_maintenance2 = true,
      .KHR_maintenance3 = true,
      .KHR_maintenance4 = true,
      .KHR_maintenance5 = true,
      .KHR_maintenance6 = true,
      .KHR_maintenance7 = true,
      .KHR_maintenance8 = true,
      .KHR_maintenance9 = true,
      .KHR_map_memory2 = true,
      .KHR_multiview = true,
      .KHR_pipeline_binary = true,
      .KHR_pipeline_executable_properties = true,
      .KHR_pipeline_library = true,
      .KHR_push_descriptor = true,
      .KHR_relaxed_block_layout = true,
      /* Bifrost (v6/v7): bounds-checked SSBOs and hardware-checked UBOs already give the
       * robustBufferAccess2 results, null descriptors are emulated (panvk_device::null_descs). */
      .KHR_robustness2 = PAN_ARCH <= 7 || PAN_ARCH >= 10,
      .KHR_sampler_mirror_clamp_to_edge = true,
      .KHR_sampler_ycbcr_conversion = true,
      .KHR_separate_depth_stencil_layouts = true,
      .KHR_shader_clock = device->kmod.dev->props.gpu_can_query_timestamp,
      .KHR_shader_draw_parameters = true,
      .KHR_shader_expect_assume = true,
      .KHR_shader_float_controls = true,
      .KHR_shader_float_controls2 = true,
      .KHR_shader_float16_int8 = true,
      .KHR_shader_fma = true,
      .KHR_shader_integer_dot_product = true,
      .KHR_shader_maximal_reconvergence = PAN_ARCH >= 9,
      .KHR_shader_non_semantic_info = true,
      .KHR_shader_quad_control = PAN_ARCH >= 9,
      .KHR_shader_relaxed_extended_instruction = true,
      .KHR_shader_subgroup_extended_types = true,
      .KHR_shader_subgroup_rotate = true,
      .KHR_shader_subgroup_uniform_control_flow = PAN_ARCH >= 9,
      .KHR_shader_terminate_invocation = true,
      .KHR_shader_untyped_pointers = PAN_ARCH >= 9,
      .KHR_spirv_1_4 = true,
      .KHR_storage_buffer_storage_class = true,
#ifdef PANVK_USE_WSI_PLATFORM
      .KHR_present_id = true,
      .KHR_present_id2 = true,
      .KHR_present_wait = true,
      .KHR_present_wait2 = true,
      .KHR_swapchain = true,
      .KHR_swapchain_mutable_format = true,
      .KHR_swapchain_maintenance1 = true,
#endif
      .KHR_synchronization2 = true,
      .KHR_timeline_semaphore = true,
      .KHR_unified_image_layouts = true,
      .KHR_uniform_buffer_standard_layout = true,
      .KHR_variable_pointers = true,
      .KHR_vertex_attribute_divisor = true,
      .KHR_vulkan_memory_model = true,
      .KHR_workgroup_memory_explicit_layout = true,
      .KHR_zero_initialize_workgroup_memory = true,
      .EXT_4444_formats = true,
      .EXT_attachment_feedback_loop_dynamic_state = true,
      .EXT_attachment_feedback_loop_layout = true,
      .EXT_border_color_swizzle = true,
      .EXT_buffer_device_address = true,
      .EXT_calibrated_timestamps =
         device->kmod.dev->props.gpu_can_query_timestamp,
      .EXT_conditional_rendering = PAN_ARCH >= 10,
      .EXT_color_write_enable = true,
      .EXT_conservative_rasterization = PAN_ARCH >= 11,
      .EXT_custom_border_color = true,
      .EXT_debug_marker = true,
      .EXT_depth_bias_control = true,
      .EXT_depth_clamp_control = true,
      .EXT_depth_clamp_zero_one = true,
      .EXT_depth_clip_enable = true,
      .EXT_depth_clip_control = true,
      .EXT_device_address_binding_report = true,
      .EXT_device_memory_report = true,
#ifdef VK_USE_PLATFORM_DISPLAY_KHR
      .EXT_display_control = true,
#endif
      .EXT_descriptor_indexing = PAN_ARCH >= 9,
      .EXT_dynamic_rendering_unused_attachments = true,
      .EXT_extended_dynamic_state = true,
      .EXT_extended_dynamic_state2 = true,
      .EXT_extended_dynamic_state3 = true,
      .EXT_external_memory_acquire_unmodified = true,
      .EXT_external_memory_dma_buf = true,
      .EXT_global_priority = true,
      .EXT_global_priority_query = true,
      .EXT_graphics_pipeline_library = true,
      .EXT_hdr_metadata = true,
      .EXT_host_image_copy = true,
      .EXT_host_query_reset = true,
      .EXT_image_2d_view_of_3d = true,
      /* EXT_image_drm_format_modifier depends on KHR_sampler_ycbcr_conversion */
      .EXT_image_drm_format_modifier = true,
      .EXT_image_robustness = true,
      .EXT_image_sliced_view_of_3d = true,
      .EXT_image_view_min_lod = true,
      .EXT_index_type_uint8 = true,
      .EXT_legacy_dithering = true,
      .EXT_line_rasterization = true,
      .EXT_load_store_op_none = true,
      .EXT_map_memory_placed = true,
      .EXT_nested_command_buffer = PAN_ARCH >= 10,
      .EXT_memory_budget = true,
      .EXT_non_seamless_cube_map = true,
      .EXT_mutable_descriptor_type = PAN_ARCH >= 9,
      .EXT_multisampled_render_to_single_sampled = true,
      .EXT_physical_device_drm = true,
      .EXT_pipeline_creation_cache_control = true,
      .EXT_pipeline_creation_feedback = true,
      .EXT_pipeline_robustness = true,
#ifdef PANVK_USE_WSI_PLATFORM
	  .EXT_present_timing =
         device->kmod.dev->props.gpu_can_query_timestamp,
#endif
      .EXT_private_data = true,
      .EXT_primitive_topology_list_restart = true,
      .EXT_provoking_vertex = true,
      .EXT_queue_family_foreign = true,
      .EXT_rasterization_order_attachment_access = PAN_ARCH >= 10,
      .EXT_rgba10x6_formats = PAN_ARCH >= 11,
      .EXT_robustness2 = PAN_ARCH <= 7 || PAN_ARCH >= 10,
      .EXT_sampler_filter_minmax = PAN_ARCH >= 10,
      .EXT_scalar_block_layout = true,
      .EXT_separate_stencil_usage = true,
      .EXT_shader_atomic_float = true,
      .EXT_shader_demote_to_helper_invocation = true,
      .EXT_shader_image_atomic_int64 = PAN_ARCH >= 9,
      .EXT_shader_module_identifier = true,
      .EXT_shader_replicated_composites = true,
      .EXT_shader_stencil_export = true,
      .EXT_shader_subgroup_ballot = true,
      .EXT_shader_subgroup_vote = true,
      .EXT_shader_tile_image = PAN_ARCH >= 9,
      .EXT_shader_uniform_buffer_unsized_array = true,
      .EXT_subgroup_size_control = true,
#ifdef PANVK_USE_WSI_PLATFORM
      .EXT_swapchain_maintenance1 = true,
#endif
      .EXT_texel_buffer_alignment = true,
      .EXT_astc_decode_mode = PAN_ARCH >= 9,
      .EXT_texture_compression_astc_hdr = true,
      .EXT_tooling_info = true,
      /* Captured from the geometry shader emulation (panvk_nir_lower_gs.c), job manager only. */
      .EXT_transform_feedback = PAN_ARCH < 9,
      .EXT_vertex_attribute_divisor = true,
      .EXT_vertex_input_dynamic_state = true,
      .EXT_ycbcr_2plane_444_formats = PAN_ARCH >= 10,
      .EXT_ycbcr_image_arrays = PAN_ARCH >= 10,
      .EXT_zero_initialize_device_memory = true,
      .EXT_inline_uniform_block = true,
      .ANDROID_external_memory_android_hardware_buffer = has_gralloc,
      .ANDROID_native_buffer = has_gralloc,
      .GOOGLE_decorate_string = true,
#ifdef PANVK_USE_WSI_PLATFORM
      .GOOGLE_display_timing = wsi_instance_supports_google_display_timing(&instance->vk, &instance->drirc.options),
#endif
      .GOOGLE_hlsl_functionality1 = true,
      .GOOGLE_user_type = true,

      .VALVE_mutable_descriptor_type = PAN_ARCH >= 9,

      .ARM_shader_core_builtins = true,
      .ARM_shader_core_properties = true,
      .ARM_scheduling_controls = true,
      .ARM_rasterization_order_attachment_access = PAN_ARCH >= 10,
   };
}

static bool
has_compressed_formats(const struct panvk_physical_device *physical_device,
                       const uint32_t required_formats)
{
   uint32_t supported_compr_fmts =
      pan_query_compressed_formats(&physical_device->kmod.dev->props);

   return (supported_compr_fmts & required_formats) == required_formats;
}

static bool
has_texture_compression_etc2(const struct panvk_physical_device *physical_device)
{
   return has_compressed_formats(physical_device,
      BITFIELD_BIT(MALI_ETC2_RGB8) |
      BITFIELD_BIT(MALI_ETC2_RGB8A1) | BITFIELD_BIT(MALI_ETC2_RGBA8) |
      BITFIELD_BIT(MALI_ETC2_R11_UNORM) | BITFIELD_BIT(MALI_ETC2_R11_SNORM) |
      BITFIELD_BIT(MALI_ETC2_RG11_UNORM) | BITFIELD_BIT(MALI_ETC2_RG11_SNORM));
}

static bool
has_texture_compression_astc_ldr(const struct panvk_physical_device *physical_device)
{
   return has_compressed_formats(physical_device, BITFIELD_BIT(MALI_ASTC_2D_LDR));
}

static bool
has_texture_compression_astc_hdr(const struct panvk_physical_device *physical_device)
{
   return has_compressed_formats(physical_device, BITFIELD_BIT(MALI_ASTC_2D_HDR));
}

static bool
has_texture_compression_bc(const struct panvk_physical_device *physical_device)
{
   return has_compressed_formats(physical_device,
      BITFIELD_BIT(MALI_BC1_UNORM) | BITFIELD_BIT(MALI_BC2_UNORM) |
      BITFIELD_BIT(MALI_BC3_UNORM) | BITFIELD_BIT(MALI_BC4_UNORM) |
      BITFIELD_BIT(MALI_BC4_SNORM) | BITFIELD_BIT(MALI_BC5_UNORM) |
      BITFIELD_BIT(MALI_BC5_SNORM) | BITFIELD_BIT(MALI_BC6H_SF16) |
      BITFIELD_BIT(MALI_BC6H_UF16) | BITFIELD_BIT(MALI_BC7_UNORM));
}

void
panvk_per_arch(get_physical_device_features)(
   const struct panvk_instance *instance,
   const struct panvk_physical_device *device, struct vk_features *features)
{
   bool has_sparse = PAN_ARCH >= 10;

   *features = (struct vk_features){
      /* Vulkan 1.0 */
      .robustBufferAccess = true,
      .fullDrawIndexUint32 = true,
      .imageCubeArray = true,
      .independentBlend = true,
      /* Emulated: the shader is lowered to a compute job spliced between the vertex job and the
       * tiler job (panvk_nir_lower_gs.c, emit_gs_job() in jm/panvk_vX_cmd_draw.c).
       *
       * This is not merely an advertisement. vk_graphics_pipeline_cmd_bind() skips every stage
       * for which vk_device_supports_stage() is false, and that reads THIS field out of
       * supported_features -- so with it false the geometry shader is never handed to
       * cmd_bind_shaders at all and the whole emulation is dead code. (The assert that would
       * have caught it is compiled out in a release build.) */
      .geometryShader = PAN_ARCH < 9,
      .tessellationShader = PAN_ARCH < 9,
      .sampleRateShading = true,
      .dualSrcBlend = true,
      .logicOp = true,
      /* JM: one indirect draw at a time, drawCount of them (CmdDraw*Indirect). */
      .multiDrawIndirect = true,
      .drawIndirectFirstInstance = true,
      .depthClamp = true,
      .depthBiasClamp = true,
      /* v6/v7: an internal geometry shader draws the lines or points (polygon_mode_gs). */
      .fillModeNonSolid = PAN_ARCH < 9,
      .depthBounds = false,
      .wideLines = true,
      .largePoints = true,
      .alphaToOne = false,
      /* v6/v7: gl_ViewportIndex from a geometry shader (panvk_nir_lower_viewport_scissor_fs). */
      .multiViewport = PAN_ARCH < 9,
      .samplerAnisotropy = true,
      .textureCompressionETC2 = has_texture_compression_etc2(device),
      .textureCompressionASTC_LDR = has_texture_compression_astc_ldr(device),
      .textureCompressionBC = has_texture_compression_bc(device),
      .occlusionQueryPrecise = true,
      .pipelineStatisticsQuery = false,
      /* On v13+, the hardware isn't speculatively referencing to invalid
         indices anymore. */
      /* v6/v7 run the vertex shader as a plain VERTEX job, once per vertex of the range --
       * IDVS is off there (panvk_vX_shader.c), which is what speculative references came
       * from. */
      .vertexPipelineStoresAndAtomics =
         PAN_ARCH < 9 ||
         (PAN_ARCH >= 13 && instance->drirc.misc.enable_vertex_pipeline_stores_atomics) ||
         instance->drirc.misc.force_enable_shader_atomics,
      .fragmentStoresAndAtomics = true,
      .shaderTessellationAndGeometryPointSize = false,
      .shaderImageGatherExtended = true,
      .shaderStorageImageExtendedFormats = true,
      .shaderStorageImageMultisample = false,
      .shaderStorageImageReadWithoutFormat = true,
      .shaderStorageImageWriteWithoutFormat = true,
      .shaderUniformBufferArrayDynamicIndexing = true,
      .shaderSampledImageArrayDynamicIndexing = true,
      .shaderStorageBufferArrayDynamicIndexing = true,
      .shaderStorageImageArrayDynamicIndexing = true,
      /* Per fragment on v6/v7, see panvk_nir_lower_clip_cull_fs. */
      .shaderClipDistance = PAN_ARCH < 9,
      .shaderCullDistance = PAN_ARCH < 9,
      .shaderFloat64 = false,
      .shaderInt64 = true,
      .shaderInt16 = true,
      .shaderResourceResidency = false,
      .shaderResourceMinLod = false,
      .sparseBinding = has_sparse,
      .sparseResidencyBuffer = has_sparse,
      .sparseResidencyImage2D = has_sparse,
      .sparseResidencyImage3D = has_sparse,
      .sparseResidency2Samples = false,
      .sparseResidency4Samples = false,
      .sparseResidency8Samples = false,
      .sparseResidency16Samples = false,
      .sparseResidencyAliased = false, /* https://gitlab.freedesktop.org/panfrost/mesa/-/issues/237 */
      .variableMultisampleRate = false,
      .inheritedQueries = false,

      /* Vulkan 1.1 */
      .storageBuffer16BitAccess = true,
      .uniformAndStorageBuffer16BitAccess = true,
      .storagePushConstant16 = true,
      .storageInputOutput16 = true,
      .multiview = true,
      .multiviewGeometryShader = false,
      .multiviewTessellationShader = false,
      .variablePointersStorageBuffer = true,
      .variablePointers = true,
      .protectedMemory = false,
      .samplerYcbcrConversion = true,
      .shaderDrawParameters = true,

      /* Vulkan 1.2 */
      .samplerMirrorClampToEdge = true,
      .drawIndirectCount = PAN_ARCH >= 10,
      .storageBuffer8BitAccess = true,
      .uniformAndStorageBuffer8BitAccess = true,
      .storagePushConstant8 = true,
      .shaderBufferInt64Atomics = PAN_ARCH >= 9,
      .shaderSharedInt64Atomics = PAN_ARCH >= 9,
      .shaderFloat16 = PAN_ARCH >= 10,
      .shaderInt8 = true,
      /* In theory, update-after-bind is supported on bifrost, but the
       * descriptor limits would be too low for the descriptorIndexing feature.
       */
      .descriptorIndexing = PAN_ARCH >= 9,
      .shaderInputAttachmentArrayDynamicIndexing = true,
      .shaderUniformTexelBufferArrayDynamicIndexing = true,
      .shaderStorageTexelBufferArrayDynamicIndexing = true,
      .shaderUniformBufferArrayNonUniformIndexing = true,
      .shaderSampledImageArrayNonUniformIndexing = true,
      .shaderStorageBufferArrayNonUniformIndexing = true,
      .shaderStorageImageArrayNonUniformIndexing = true,
      .shaderInputAttachmentArrayNonUniformIndexing = true,
      .shaderUniformTexelBufferArrayNonUniformIndexing = true,
      .shaderStorageTexelBufferArrayNonUniformIndexing = true,
      .descriptorBindingUniformBufferUpdateAfterBind = PAN_ARCH >= 9,
      .descriptorBindingSampledImageUpdateAfterBind = PAN_ARCH >= 9,
      .descriptorBindingStorageImageUpdateAfterBind = PAN_ARCH >= 9,
      .descriptorBindingStorageBufferUpdateAfterBind = PAN_ARCH >= 9,
      .descriptorBindingUniformTexelBufferUpdateAfterBind = PAN_ARCH >= 9,
      .descriptorBindingStorageTexelBufferUpdateAfterBind = PAN_ARCH >= 9,
      .descriptorBindingUpdateUnusedWhilePending = PAN_ARCH >= 9,
      .descriptorBindingPartiallyBound = PAN_ARCH >= 9,
      .descriptorBindingVariableDescriptorCount = true,
      .runtimeDescriptorArray = true,
      .samplerFilterMinmax = PAN_ARCH >= 10,
      .scalarBlockLayout = true,
      .imagelessFramebuffer = true,
      .uniformBufferStandardLayout = true,
      .shaderSubgroupExtendedTypes = true,
      .separateDepthStencilLayouts = true,
      .hostQueryReset = true,
      .timelineSemaphore = true,
      .bufferDeviceAddress = true,
      /* only expose for CSF/panthor, and if we have extended VA ranges */
      .bufferDeviceAddressCaptureReplay =
         (PAN_ARCH >= 10) && (device->memory.max_supported_va > (1ull << 32)),
      .bufferDeviceAddressMultiDevice = false,
      .vulkanMemoryModel = true,
      .vulkanMemoryModelDeviceScope = true,
      .vulkanMemoryModelAvailabilityVisibilityChains = true,
      .shaderOutputViewportIndex = false,
      .shaderOutputLayer = false,
      .subgroupBroadcastDynamicId = true,

      /* Vulkan 1.3 */
      .robustImageAccess = true,
      .inlineUniformBlock = true,
      .descriptorBindingInlineUniformBlockUpdateAfterBind = true,
      .pipelineCreationCacheControl = true,
      .privateData = true,
      .shaderDemoteToHelperInvocation = true,
      .shaderTerminateInvocation = true,
      .subgroupSizeControl = true,
      .computeFullSubgroups = true,
      .synchronization2 = true,
      .textureCompressionASTC_HDR = has_texture_compression_astc_hdr(device),
      .shaderZeroInitializeWorkgroupMemory = true,

      /* VK_EXT_astc_decode_mode */
      .decodeModeSharedExponent = false,

      .dynamicRendering = true,
      .shaderIntegerDotProduct = true,
      .maintenance4 = true,

      /* Vulkan 1.4 */
      .globalPriorityQuery = true,
      .shaderSubgroupRotate = true,
      .shaderSubgroupRotateClustered = true,
      .shaderFloatControls2 = true,
      .shaderExpectAssume = true,
      .rectangularLines = true,
      .bresenhamLines = true,
      .smoothLines = false,
      .stippledRectangularLines = false,
      .stippledBresenhamLines = false,
      .stippledSmoothLines = false,
      .vertexAttributeInstanceRateDivisor = true,
      .vertexAttributeInstanceRateZeroDivisor = true,
      .indexTypeUint8 = true,
      .dynamicRenderingLocalRead = true,
      .maintenance5 = true,
      .maintenance6 = true,
      .pipelineProtectedAccess = false,
      .pipelineRobustness = true,
      .hostImageCopy = true,
      .pushDescriptor = true,

      /* VK_KHR_depth_clamp_zero_one */
      .depthClampZeroOne = true,

      /* VK_KHR_compute_shader_derivatives */
      .computeDerivativeGroupQuads = PAN_ARCH >= 9,
      .computeDerivativeGroupLinear = PAN_ARCH >= 9,

      /* VK_KHR_cooperative_matrix */
      .cooperativeMatrix = PAN_ARCH >= 11,
      .cooperativeMatrixRobustBufferAccess = false,

      /* VK_KHR_maintenance7 */
      .maintenance7 = true,

      /* VK_KHR_maintenance8 */
      .maintenance8 = true,

      /* VK_KHR_maintenance9 */
      .maintenance9 = true,

      /* VK_KHR_internally_synchronized_queues */
      .internallySynchronizedQueues = true,

      /* VK_EXT_graphics_pipeline_library */
      .graphicsPipelineLibrary = true,

      /* VK_EXT_vertex_input_dynamic_state */
      .vertexInputDynamicState = true,

      /* VK_EXT_depth_bias_control */
      .depthBiasControl = true,
      .leastRepresentableValueForceUnormRepresentation = false,
      .floatRepresentation = false,
      .depthBiasExact = true,

      /* VK_EXT_depth_clamp_control */
      .depthClampControl = true,

      /* VK_EXT_depth_clip_control */
      .depthClipControl = true,

      /* VK_EXT_depth_clip_enable */
      .depthClipEnable = true,

      /* VK_EXT_dynamic_rendering_unused_attachments */
      .dynamicRenderingUnusedAttachments = true,

      /* VK_EXT_extended_dynamic_state */
      .extendedDynamicState = true,

      /* VK_EXT_extended_dynamic_state2 */
      .extendedDynamicState2 = true,
      .extendedDynamicState2LogicOp = true,
      .extendedDynamicState2PatchControlPoints = false,

      /* VK_EXT_extended_dynamic_state3 */
      .extendedDynamicState3TessellationDomainOrigin = false,
      .extendedDynamicState3DepthClampEnable = true,
      .extendedDynamicState3PolygonMode = false,
      .extendedDynamicState3RasterizationSamples = true,
      .extendedDynamicState3SampleMask = true,
      .extendedDynamicState3AlphaToCoverageEnable = true,
      .extendedDynamicState3AlphaToOneEnable = false,
      .extendedDynamicState3LogicOpEnable = true,
      .extendedDynamicState3ColorBlendEnable = true,
      .extendedDynamicState3ColorBlendEquation = true,
      .extendedDynamicState3ColorWriteMask = true,
      .extendedDynamicState3RasterizationStream = false,
      .extendedDynamicState3ConservativeRasterizationMode = PAN_ARCH >= 11,
      .extendedDynamicState3ExtraPrimitiveOverestimationSize = false,
      .extendedDynamicState3DepthClipEnable = true,
      .extendedDynamicState3SampleLocationsEnable = false,
      .extendedDynamicState3ColorBlendAdvanced = false,
      .extendedDynamicState3ProvokingVertexMode = false,
      .extendedDynamicState3LineRasterizationMode = true,
      .extendedDynamicState3LineStippleEnable = false,
      .extendedDynamicState3DepthClipNegativeOneToOne = false,
      .extendedDynamicState3ViewportWScalingEnable = false,
      .extendedDynamicState3ViewportSwizzle = false,
      .extendedDynamicState3CoverageToColorEnable = false,
      .extendedDynamicState3CoverageToColorLocation = false,
      .extendedDynamicState3CoverageModulationMode = false,
      .extendedDynamicState3CoverageModulationTableEnable = false,
      .extendedDynamicState3CoverageModulationTable = false,
      .extendedDynamicState3CoverageReductionMode = false,
      .extendedDynamicState3RepresentativeFragmentTestEnable = false,
      .extendedDynamicState3ShadingRateImageEnable = false,

      /* VK_EXT_attachment_feedback_loop_dynamic_state */
      .attachmentFeedbackLoopDynamicState = true,

      /* VK_EXT_attachment_feedback_loop_layout */
      .attachmentFeedbackLoopLayout = true,

      /* VK_EXT_4444_formats */
      .formatA4R4G4B4 = true,
      .formatA4B4G4R4 = true,

      /* VK_EXT_color_write_enable */
      .colorWriteEnable = true,

      /* VK_KHR_copy_memory_indirect */
      .indirectMemoryCopy = PAN_ARCH >= 10,

      /* VK_EXT_conditional_rendering */
      .conditionalRendering = PAN_ARCH >= 10,
      .inheritedConditionalRendering = PAN_ARCH >= 10,

      /* VK_EXT_custom_border_color */
      .customBorderColors = true,

      /* VK_EXT_border_color_swizzle */
      .borderColorSwizzle = true,
      .borderColorSwizzleFromImage = true,

      /* VK_EXT_image_2d_view_of_3d */
      .image2DViewOf3D = true,
      .sampler2DViewOf3D = true,

      /* VK_EXT_image_sliced_view_of_3d */
      .imageSlicedViewOf3D = true,

      /* VK_EXT_image_view_min_lod */
      .minLod = true,

      /* VK_EXT_transform_feedback: from geometry shaders, stream 0. */
      .transformFeedback = PAN_ARCH < 9,
      .geometryStreams = PAN_ARCH < 9,

      /* VK_EXT_primitive_topology_list_restart */
      .primitiveTopologyListRestart = true,
      .primitiveTopologyPatchListRestart = false,

      /* VK_EXT_provoking_vertex */
      .provokingVertexLast = true,
      .transformFeedbackPreservesProvokingVertex = false,

      /* v7 doesn't support AFBC(BGR). We need to tweak the texture swizzle to
       * make it work, which forces us to apply the same swizzle on the border
       * color, meaning we need to know the format when preparing the border
       * color.
       */
      .customBorderColorWithoutFormat = PAN_ARCH != 7,

      /* VK_KHR_pipeline_binary */
      .pipelineBinaries = true,

      /* VK_KHR_pipeline_executable_properties */
      .pipelineExecutableInfo = true,

      /* VK_KHR_robustness2 */
      .robustBufferAccess2 = PAN_ARCH <= 7 || PAN_ARCH >= 11,
      .robustImageAccess2 = false,
      .nullDescriptor = PAN_ARCH <= 7 || PAN_ARCH >= 10,

      /* VK_EXT_shader_tile_image */
      .shaderTileImageColorReadAccess = PAN_ARCH >= 9,
      .shaderTileImageDepthReadAccess = PAN_ARCH >= 9,
      .shaderTileImageStencilReadAccess = PAN_ARCH >= 9,

      /* VK_KHR_shader_clock */
      .shaderSubgroupClock = device->kmod.dev->props.gpu_can_query_timestamp,
      .shaderDeviceClock = device->kmod.dev->props.timestamp_device_coherent,

      /* VK_KHR_shader_quad_control */
      .shaderQuadControl = true,

      /* VK_KHR_shader_relaxed_extended_instruction */
      .shaderRelaxedExtendedInstruction = true,

      /* VK_KHR_shader_maximal_reconvergence */
      .shaderMaximalReconvergence = true,

      /* VK_KHR_shader_subgroup_uniform_control_flow */
      .shaderSubgroupUniformControlFlow = true,

      /* VK_KHR_shader_untyped_pointers */
      .shaderUntypedPointers = PAN_ARCH >= 9,

      /* VK_KHR_workgroup_memory_explicit_layout */
      .workgroupMemoryExplicitLayout = true,
      .workgroupMemoryExplicitLayoutScalarBlockLayout = true,
      .workgroupMemoryExplicitLayout8BitAccess = true,
      .workgroupMemoryExplicitLayout16BitAccess = true,

      /* VK_EXT_shader_module_identifier */
      .shaderModuleIdentifier = true,

      /* VK_EXT_shader_replicated_composites */
      .shaderReplicatedComposites = true,

      /* VK_EXT_shader_uniform_buffer_unsized_array */
      .shaderUniformBufferUnsizedArray = true,

      /* VK_EXT_shader_atomic_float */
      .shaderBufferFloat32Atomics = true,
      .shaderBufferFloat32AtomicAdd = false,
      .shaderBufferFloat64Atomics = false,
      .shaderBufferFloat64AtomicAdd = false,
      .shaderSharedFloat32Atomics = true,
      .shaderSharedFloat32AtomicAdd = false,
      .shaderSharedFloat64Atomics = false,
      .shaderSharedFloat64AtomicAdd = false,
      .shaderImageFloat32Atomics = true,
      .shaderImageFloat32AtomicAdd = false,
      .sparseImageFloat32Atomics = has_sparse,
      .sparseImageFloat32AtomicAdd = false,

      /* VK_EXT_shader_image_atomic_int64 */
      .shaderImageInt64Atomics = PAN_ARCH >= 9,
      .sparseImageInt64Atomics = false,

      /* VK_EXT_texel_buffer_alignment */
      .texelBufferAlignment = true,

      /* VK_EXT_rgba10x6_formats */
      .formatRgba10x6WithoutYCbCrSampler = PAN_ARCH >= 11,

      /* VK_EXT_ycbcr_2plane_444_formats */
      .ycbcr2plane444Formats = PAN_ARCH >= 10,

      /* VK_EXT_ycbcr_image_arrays */
      .ycbcrImageArrays = PAN_ARCH >= 10,

      /* VK_EXT_legacy_dithering */
      .legacyDithering = true,

      /* VK_EXT_nested_command_buffer */
      .nestedCommandBuffer = PAN_ARCH >= 10,
      .nestedCommandBufferRendering = PAN_ARCH >= 10,
      .nestedCommandBufferSimultaneousUse = PAN_ARCH >= 10,

      /* VK_EXT_map_memory_placed */
      .memoryMapPlaced = true,
      .memoryMapRangePlaced = false,
      .memoryUnmapReserve = true,

      /* VK_EXT_non_seamless_cube_map */
      .nonSeamlessCubeMap = true,

      /* VK_KHR_unified_image_layouts */
      .unifiedImageLayouts = true,
      /* Video is not currently supported, so set to false */
      .unifiedImageLayoutsVideo = false,

      /* VK_EXT_zero_initialize_device_memory */
      .zeroInitializeDeviceMemory = true,

      /* VK_EXT_mutable_descriptor_type */
      .mutableDescriptorType = PAN_ARCH >= 9,

      /* VK_KHR_shader_fma */
      .shaderFmaFloat16 = PAN_ARCH >= 10,
      .shaderFmaFloat32 = true,
      .shaderFmaFloat64 = false,

#ifdef PANVK_USE_WSI_PLATFORM
      /* VK_KHR_present_id */
      .presentId = true,

      /* VK_KHR_present_id2 */
      .presentId2 = true,

      /* VK_KHR_present_wait */
      .presentWait = true,

      /* VK_KHR_present_wait2 */
      .presentWait2 = true,
#endif

      /* VK_EXT_device_address_binding_report */
      .reportAddressBinding = true,

      /* VK_EXT_device_memory_report */
      .deviceMemoryReport = true,

      /* VK_ARM_shader_core_builtins */
      .shaderCoreBuiltins = true,

      /* VK_ARM_scheduling_controls */
      .schedulingControls = true,

#ifdef PANVK_USE_WSI_PLATFORM
      /* KHR_swapchain_maintenance1 */
      .swapchainMaintenance1 = true,
#endif

      /* VK_EXT_multisampled_render_to_single_sampled */
      .multisampledRenderToSingleSampled = true,

#ifdef PANVK_USE_WSI_PLATFORM
      /* VK_EXT_present_timing */
      .presentTiming = true,
      .presentAtRelativeTime = true,
      .presentAtAbsoluteTime = true,
#endif

      /* VK_EXT_rasterization_order_attachment_access */
      .rasterizationOrderColorAttachmentAccess = PAN_ARCH >= 10,
      .rasterizationOrderDepthAttachmentAccess = PAN_ARCH >= 10,
      .rasterizationOrderStencilAttachmentAccess = PAN_ARCH >= 10,
   };
}

static uint32_t
get_api_version()
{
   const uint32_t version_override = vk_get_version_override();
   if (version_override)
      return version_override;

   if (PAN_ARCH >= 10)
      return VK_MAKE_API_VERSION(0, 1, 4, VK_HEADER_VERSION);

   return VK_MAKE_API_VERSION(0, 1, 3, VK_HEADER_VERSION);
}

static VkConformanceVersion
get_conformance_version()
{
   if (PAN_ARCH == 10)
      return (VkConformanceVersion){1, 4, 1, 2};

   return (VkConformanceVersion){0, 0, 0, 0};
}

void
panvk_per_arch(get_physical_device_properties)(
   const struct panvk_instance *instance,
   const struct panvk_physical_device *device, struct vk_properties *properties)
{
   unsigned max_tib_size = pan_query_tib_size(device->model);
   const unsigned max_cbuf_format = 16; /* R32G32B32A32 */

   unsigned max_cbuf_atts = pan_get_max_cbufs(PAN_ARCH, max_tib_size);
   VkSampleCountFlags sample_counts =
       panvk_get_sample_counts(PAN_ARCH, max_tib_size, max_cbuf_atts,
                               max_cbuf_format);

   uint64_t os_page_size = 4096;
   os_get_page_size(&os_page_size);

   const bool has_disk_cache = device->vk.disk_cache != NULL;

   /* Ensure that the max threads count per workgroup is valid for Bifrost */
   assert(PAN_ARCH > 8 || device->kmod.dev->props.max_threads_per_wg <= 1024);

   float pointSizeRangeMin;
   float pointSizeRangeMax;

   /* On v13+, point size handling changed entirely */
   if (PAN_ARCH >= 13) {
      pointSizeRangeMin = 1.0;
      pointSizeRangeMax = 1024.0;
   } else {
      pointSizeRangeMin = 0.125;
      pointSizeRangeMax = 4095.9375;
   }

   *properties = (struct vk_properties){
      .apiVersion = get_api_version(),
      .driverVersion = vk_get_driver_version(),
      .vendorID =
         instance->drirc.debug.force_vk_vendor ? instance->drirc.debug.force_vk_vendor : ARM_VENDOR_ID,
      .deviceID = device->kmod.dev->props.gpu_id,
      .deviceType = VK_PHYSICAL_DEVICE_TYPE_INTEGRATED_GPU,

      /* Vulkan 1.0 limits */
      /* Maximum texture dimension is 2^16. */
      .maxImageDimension1D = (1 << 16),
      .maxImageDimension2D = (1 << 16),
      .maxImageDimension3D = (1 << 16),
      .maxImageDimensionCube = (1 << 16),
      .maxImageArrayLayers = (1 << 16),
      .maxTexelBufferElements = UINT64_C(1) << (util_logbase2(panvk_get_max_buffer_size(device) / 16)),
      /* Each uniform entry is 16-byte and the number of entries is encoded in a
       * 12-bit field, with the minus(1) modifier, which gives 2^20.
       */
      .maxUniformBufferRange = 1 << 20,
      /* Storage buffer access is lowered to globals, so there's no limit here,
       * except for the SW-descriptor we use to encode storage buffer
       * descriptors, where the size is a 32-bit field.
       */
      .maxStorageBufferRange = UINT32_MAX,
      /* Vulkan 1.4 minimum. We currently implement push constants in terms of
       * FAUs so we're limited by how many user-defined FAUs the hardware
       * offers, minus driver-internal needs. If we ever need go to higher,
       * we'll have to implement push constants in terms of both FAUs and global
       * loads.
       */
      .maxPushConstantsSize = 256,
      /* On our kernel drivers we're limited by the available memory rather
       * than available allocations. This is better expressed through memory
       * properties and budget queries, and by returning
       * VK_ERROR_OUT_OF_DEVICE_MEMORY when applicable, rather than
       * this limit.
       */
      .maxMemoryAllocationCount = UINT32_MAX,
      /* On Mali, VkSampler objects do not use any resources other than host
       * memory and host address space, availability of which can change
       * significantly over time.
       */
      .maxSamplerAllocationCount = UINT32_MAX,
      /* A cache line. */
      .bufferImageGranularity = 64,
      /* The entire user-allocatable VA range. */
      .sparseAddressSpaceSize =
         pan_kmod_dev_query_user_va_range(device->kmod.dev).size,
      .maxBoundDescriptorSets = MAX_SETS,
      .maxPerStageDescriptorSamplers = MAX_PER_STAGE_SAMPLERS,
      .maxPerStageDescriptorUniformBuffers = MAX_PER_STAGE_UNIFORM_BUFFERS,
      .maxPerStageDescriptorStorageBuffers = MAX_PER_STAGE_STORAGE_BUFFERS,
      .maxPerStageDescriptorSampledImages = MAX_PER_STAGE_SAMPLED_IMAGES,
      .maxPerStageDescriptorStorageImages = MAX_PER_STAGE_STORAGE_IMAGES,
      .maxPerStageDescriptorInputAttachments = MAX_PER_STAGE_INPUT_ATTACHMENTS,
      .maxPerStageResources = MAX_PER_STAGE_RESOURCES,
      .maxDescriptorSetSamplers = MAX_PER_SET_SAMPLERS,
      .maxDescriptorSetUniformBuffers = MAX_PER_SET_UNIFORM_BUFFERS,
      /* Software limit to keep VkCommandBuffer tracking sane. */
      .maxDescriptorSetUniformBuffersDynamic = MAX_DYNAMIC_UNIFORM_BUFFERS,
      .maxDescriptorSetStorageBuffers = MAX_PER_SET_STORAGE_BUFFERS,
      /* Software limit to keep VkCommandBuffer tracking sane. */
      .maxDescriptorSetStorageBuffersDynamic = MAX_DYNAMIC_STORAGE_BUFFERS,
      .maxDescriptorSetSampledImages = MAX_PER_SET_SAMPLED_IMAGES,
      .maxDescriptorSetStorageImages = MAX_PER_SET_STORAGE_IMAGES,
      .maxDescriptorSetInputAttachments = MAX_PER_SET_INPUT_ATTACHMENTS,
      /* Software limit to keep VkCommandBuffer tracking sane. The HW supports
       * up to 2^9 vertex attributes.
       */
      .maxVertexInputAttributes = MAX_VBS,
      .maxVertexInputBindings = MAX_VBS,
      /* MALI_ATTRIBUTE::offset is 32-bit. */
      .maxVertexInputAttributeOffset = UINT32_MAX,
      /* MALI_ATTRIBUTE_BUFFER::stride is 32-bit. */
      .maxVertexInputBindingStride = MESA_VK_MAX_VERTEX_BINDING_STRIDE,
      /* 32 vec4 varyings. */
      .maxVertexOutputComponents = 128,
      /* v6/v7 emulate tessellation (panvk_nir_lower_gs.c); these are the spec minimums. */
      .maxTessellationGenerationLevel = PAN_ARCH < 9 ? 64 : 0,
      .maxTessellationPatchSize = PAN_ARCH < 9 ? 32 : 0,
      .maxTessellationControlPerVertexInputComponents = PAN_ARCH < 9 ? 64 : 0,
      .maxTessellationControlPerVertexOutputComponents = PAN_ARCH < 9 ? 64 : 0,
      .maxTessellationControlPerPatchOutputComponents = PAN_ARCH < 9 ? 120 : 0,
      .maxTessellationControlTotalOutputComponents = PAN_ARCH < 9 ? 2048 : 0,
      .maxTessellationEvaluationInputComponents = PAN_ARCH < 9 ? 64 : 0,
      .maxTessellationEvaluationOutputComponents = PAN_ARCH < 9 ? 64 : 0,
      /* Matching what the vendor driver reports on the same chip, except invocations: the
       * emulation runs a geometry shader once per input primitive, not N times. */
      /* One emulation invocation per (primitive, gl_InvocationID); 32 is the spec minimum. */
      .maxGeometryShaderInvocations = PAN_ARCH < 9 ? 32 : 1,
      .maxGeometryInputComponents = PAN_ARCH < 9 ? 64 : 0,
      .maxGeometryOutputComponents = PAN_ARCH < 9 ? 128 : 0,
      .maxGeometryOutputVertices = PAN_ARCH < 9 ? 256 : 0,
      .maxGeometryTotalOutputComponents = PAN_ARCH < 9 ? 1024 : 0,
      /* 32 vec4 varyings. */
      .maxFragmentInputComponents = 128,
      /* 8 render targets. */
      .maxFragmentOutputAttachments = MAX_RTS,
      .maxFragmentDualSrcAttachments = max_cbuf_atts,
      /* 8 render targets, 2^12 storage buffers and 2^8 storage images (see
       * above).
       */
      .maxFragmentCombinedOutputResources = MAX_RTS + (1 << 12) + (1 << 8),
      /* MALI_LOCAL_STORAGE::wls_size_{base,scale} allows us to have up to
       * (7 << 30) bytes of shared memory, but we cap it to 32K as it doesn't
       * really make sense to expose this amount of memory, especially since
       * it's backed by global memory anyway.
       */
      .maxComputeSharedMemorySize = 32768,
      /* Software limit to meet Vulkan 1.0 requirements. We split the
       * dispatch in several jobs if it's too big.
       */
      .maxComputeWorkGroupCount = {65535, 65535, 65535},
      /* We could also split into serveral jobs but this has many limitations.
       * As such we limit to the max threads per workgroup supported by the GPU.
       */
      .maxComputeWorkGroupInvocations =
         device->kmod.dev->props.max_threads_per_wg,
      .maxComputeWorkGroupSize = {device->kmod.dev->props.max_threads_per_wg,
                                  device->kmod.dev->props.max_threads_per_wg,
                                  device->kmod.dev->props.max_threads_per_wg},
      /* 8-bit subpixel precision. */
      .subPixelPrecisionBits = 8,
      .subTexelPrecisionBits = 8,
      .mipmapPrecisionBits = 8,
      /* Software limit. */
      .maxDrawIndexedIndexValue = UINT32_MAX,
      .maxDrawIndirectCount = UINT32_MAX,
      .maxSamplerLodBias = (float)INT16_MAX / 256.0f,
      .maxSamplerAnisotropy = 16,
      .maxViewports = PAN_ARCH < 9 ? 16 : 1,
      .maxViewportDimensions = {MAX_FRAMEBUFFER_DIMENSION, MAX_FRAMEBUFFER_DIMENSION},
      .viewportBoundsRange = {-2.0f * MAX_FRAMEBUFFER_DIMENSION, 2.0f * MAX_FRAMEBUFFER_DIMENSION - 1.0f},
      .viewportSubPixelBits = 0,
      /* Align on a page. */
      .minMemoryMapAlignment = os_page_size,
      /* The largest buffer texture format is 16B */
      .minTexelBufferOffsetAlignment = 16,
      /* Always aligned on a uniform slot (vec4). */
      .minUniformBufferOffsetAlignment = 16,
      /* LOAD.i128 and LD_PKA.i128 which require 16B alignment */
      .minStorageBufferOffsetAlignment = 16,
      /* Signed 4-bit value. */
      .minTexelOffset = -8,
      .maxTexelOffset = 7,
      .minTexelGatherOffset = -8,
      .maxTexelGatherOffset = 7,
      .minInterpolationOffset = -0.5,
      .maxInterpolationOffset = 0.5,
      .subPixelInterpolationOffsetBits = 8,
      .maxFramebufferWidth = MAX_FRAMEBUFFER_DIMENSION,
      .maxFramebufferHeight = MAX_FRAMEBUFFER_DIMENSION,
      .maxFramebufferLayers = MAX_FRAMEBUFFER_LAYERS,
      .framebufferColorSampleCounts = sample_counts,
      .framebufferDepthSampleCounts = sample_counts,
      .framebufferStencilSampleCounts = sample_counts,
      .framebufferNoAttachmentsSampleCounts = sample_counts,
      .maxColorAttachments = max_cbuf_atts,
      .sampledImageColorSampleCounts = sample_counts,
      .sampledImageIntegerSampleCounts = sample_counts,
      .sampledImageDepthSampleCounts = sample_counts,
      .sampledImageStencilSampleCounts = sample_counts,
      .storageImageSampleCounts = VK_SAMPLE_COUNT_1_BIT,
      .maxSampleMaskWords = 1,
      .timestampComputeAndGraphics =
         PAN_ARCH >= 10 && device->kmod.dev->props.gpu_can_query_timestamp,
      .timestampPeriod =
         PAN_ARCH >= 10 ? panvk_get_gpu_system_timestamp_period(device) : 0,
      .maxClipDistances = PAN_ARCH < 9 ? 8 : 0,
      .maxCullDistances = PAN_ARCH < 9 ? 8 : 0,
      .maxCombinedClipAndCullDistances = PAN_ARCH < 9 ? 8 : 0,
      .discreteQueuePriorities = 2,
      .pointSizeRange = {pointSizeRangeMin, pointSizeRangeMax},
      .lineWidthRange = {0.0, 7.9921875},
      .pointSizeGranularity = (1.0 / 16.0),
      .lineWidthGranularity = (1.0 / 128.0),
      .strictLines = true,
      .standardSampleLocations = true,
      .optimalBufferCopyOffsetAlignment = 64,
      .optimalBufferCopyRowPitchAlignment = 64,

      /* If we can't detect the cacheline size, assume 64 bytes cachelines. */
      .nonCoherentAtomSize = util_has_cache_ops() ? util_cache_granularity() : 64,

      /* Vulkan 1.0 sparse properties */
      .sparseResidencyNonResidentStrict = false,
      .sparseResidencyAlignedMipSize = false,
      .sparseResidencyStandard2DBlockShape = true,
      .sparseResidencyStandard2DMultisampleBlockShape = false,
      .sparseResidencyStandard3DBlockShape = false,

      /* Vulkan 1.1 properties */
      .subgroupSize = pan_subgroup_size(PAN_ARCH),
      /* We only support VS, FS, and CS.
       *
       * The HW may spawn VS invocations for non-existing indices, which could
       * be observed through subgroup ops (though the user can observe them
       * through infinte loops anyway), so subgroup ops can't be supported in
       * VS.
       */
      .subgroupSupportedStages =
         VK_SHADER_STAGE_FRAGMENT_BIT | VK_SHADER_STAGE_COMPUTE_BIT,
      .subgroupSupportedOperations =
         VK_SUBGROUP_FEATURE_BASIC_BIT | VK_SUBGROUP_FEATURE_VOTE_BIT |
         VK_SUBGROUP_FEATURE_ARITHMETIC_BIT | VK_SUBGROUP_FEATURE_BALLOT_BIT |
         VK_SUBGROUP_FEATURE_SHUFFLE_BIT |
         VK_SUBGROUP_FEATURE_SHUFFLE_RELATIVE_BIT |
         VK_SUBGROUP_FEATURE_CLUSTERED_BIT | VK_SUBGROUP_FEATURE_QUAD_BIT |
         VK_SUBGROUP_FEATURE_ROTATE_BIT |
         VK_SUBGROUP_FEATURE_ROTATE_CLUSTERED_BIT,
      .subgroupQuadOperationsInAllStages = false,
      .pointClippingBehavior = VK_POINT_CLIPPING_BEHAVIOR_ALL_CLIP_PLANES,
      .maxMultiviewViewCount = pan_max_multiview_view_count(PAN_ARCH),
      .maxMultiviewInstanceIndex = UINT32_MAX,
      .protectedNoFault = false,
      .maxPerSetDescriptors = UINT16_MAX,
      /* Our buffer size fields allow only this much */
      .maxMemoryAllocationSize = UINT32_MAX,

      /* Vulkan 1.2 properties */
      .supportedDepthResolveModes =
         VK_RESOLVE_MODE_SAMPLE_ZERO_BIT | VK_RESOLVE_MODE_AVERAGE_BIT |
         VK_RESOLVE_MODE_MIN_BIT | VK_RESOLVE_MODE_MAX_BIT,
      .supportedStencilResolveModes = VK_RESOLVE_MODE_SAMPLE_ZERO_BIT |
                                      VK_RESOLVE_MODE_MIN_BIT |
                                      VK_RESOLVE_MODE_MAX_BIT,
      .independentResolveNone = true,
      .independentResolve = true,
      /* VK_KHR_driver_properties */
      .driverID = VK_DRIVER_ID_MESA_PANVK,
      .conformanceVersion = get_conformance_version(),
      .denormBehaviorIndependence =
         PAN_ARCH >= 9 ? VK_SHADER_FLOAT_CONTROLS_INDEPENDENCE_NONE
                       : VK_SHADER_FLOAT_CONTROLS_INDEPENDENCE_ALL,
      .roundingModeIndependence = VK_SHADER_FLOAT_CONTROLS_INDEPENDENCE_ALL,
      .shaderSignedZeroInfNanPreserveFloat16 = true,
      .shaderSignedZeroInfNanPreserveFloat32 = true,
      .shaderSignedZeroInfNanPreserveFloat64 = false,
      .shaderDenormPreserveFloat16 = true,
      .shaderDenormPreserveFloat32 = true,
      .shaderDenormPreserveFloat64 = true,
      .shaderDenormFlushToZeroFloat16 = true,
      .shaderDenormFlushToZeroFloat32 = true,
      .shaderDenormFlushToZeroFloat64 = true,
      .shaderRoundingModeRTEFloat16 = true,
      .shaderRoundingModeRTEFloat32 = true,
      .shaderRoundingModeRTEFloat64 = false,
      .shaderRoundingModeRTZFloat16 = true,
      .shaderRoundingModeRTZFloat32 = true,
      .shaderRoundingModeRTZFloat64 = false,
      .maxUpdateAfterBindDescriptorsInAllPools =
         PAN_ARCH >= 9 ? UINT32_MAX : 0,
      /* VK_EXT_descriptor_indexing */
      .maxUpdateAfterBindDescriptorsInAllPools = PAN_ARCH >= 9 ? UINT32_MAX : 0,
      .shaderUniformBufferArrayNonUniformIndexingNative = false,
      .shaderSampledImageArrayNonUniformIndexingNative = false,
      .shaderStorageBufferArrayNonUniformIndexingNative = false,
      .shaderStorageImageArrayNonUniformIndexingNative = false,
      .shaderInputAttachmentArrayNonUniformIndexingNative = false,
      .robustBufferAccessUpdateAfterBind = PAN_ARCH >= 9,
      .quadDivergentImplicitLod = false,
      .maxPerStageDescriptorUpdateAfterBindSamplers =
         PAN_ARCH >= 9 ? MAX_PER_STAGE_SAMPLERS : 0,
      .maxPerStageDescriptorUpdateAfterBindUniformBuffers =
         PAN_ARCH >= 9 ? MAX_PER_STAGE_UNIFORM_BUFFERS : 0,
      .maxPerStageDescriptorUpdateAfterBindStorageBuffers =
         PAN_ARCH >= 9 ? MAX_PER_STAGE_STORAGE_BUFFERS : 0,
      .maxPerStageDescriptorUpdateAfterBindSampledImages =
         PAN_ARCH >= 9 ? MAX_PER_STAGE_SAMPLED_IMAGES : 0,
      .maxPerStageDescriptorUpdateAfterBindStorageImages =
         PAN_ARCH >= 9 ? MAX_PER_STAGE_STORAGE_IMAGES : 0,
      .maxPerStageDescriptorUpdateAfterBindInputAttachments =
         PAN_ARCH >= 9 ? MAX_PER_STAGE_INPUT_ATTACHMENTS : 0,
      .maxPerStageUpdateAfterBindResources =
         PAN_ARCH >= 9 ? MAX_PER_STAGE_RESOURCES : 0,
      .maxDescriptorSetUpdateAfterBindSamplers =
         PAN_ARCH >= 9 ? MAX_PER_SET_SAMPLERS : 0,
      .maxDescriptorSetUpdateAfterBindUniformBuffers =
         PAN_ARCH >= 9 ? MAX_PER_SET_UNIFORM_BUFFERS : 0,
      .maxDescriptorSetUpdateAfterBindUniformBuffersDynamic =
         PAN_ARCH >= 9 ? MAX_DYNAMIC_UNIFORM_BUFFERS : 0,
      .maxDescriptorSetUpdateAfterBindStorageBuffers =
         PAN_ARCH >= 9 ? MAX_PER_SET_STORAGE_BUFFERS : 0,
      .maxDescriptorSetUpdateAfterBindStorageBuffersDynamic =
         PAN_ARCH >= 9 ? MAX_DYNAMIC_STORAGE_BUFFERS : 0,
      .maxDescriptorSetUpdateAfterBindSampledImages =
         PAN_ARCH >= 9 ? MAX_PER_SET_SAMPLED_IMAGES : 0,
      .maxDescriptorSetUpdateAfterBindStorageImages =
         PAN_ARCH >= 9 ? MAX_PER_SET_STORAGE_IMAGES : 0,
      .maxDescriptorSetUpdateAfterBindInputAttachments =
         PAN_ARCH >= 9 ? MAX_PER_SET_INPUT_ATTACHMENTS : 0,
      .supportedDepthResolveModes = VK_RESOLVE_MODE_SAMPLE_ZERO_BIT |
                                    VK_RESOLVE_MODE_AVERAGE_BIT |
                                    VK_RESOLVE_MODE_MIN_BIT |
                                    VK_RESOLVE_MODE_MAX_BIT,
      .supportedStencilResolveModes = VK_RESOLVE_MODE_SAMPLE_ZERO_BIT |
                                      VK_RESOLVE_MODE_MIN_BIT |
                                      VK_RESOLVE_MODE_MAX_BIT,
      .independentResolveNone = true,
      .independentResolve = true,
      .filterMinmaxSingleComponentFormats = PAN_ARCH >= 10,
      .filterMinmaxImageComponentMapping = PAN_ARCH >= 10,
      .maxTimelineSemaphoreValueDifference = INT64_MAX,
      .framebufferIntegerColorSampleCounts = sample_counts,

      /* Vulkan 1.3 properties */
      .minSubgroupSize = pan_subgroup_size(PAN_ARCH),
      .maxSubgroupSize = pan_subgroup_size(PAN_ARCH),
      .maxComputeWorkgroupSubgroups =
         device->kmod.dev->props.max_threads_per_wg /
         pan_subgroup_size(PAN_ARCH),
      .requiredSubgroupSizeStages = VK_SHADER_STAGE_COMPUTE_BIT,
      .maxInlineUniformBlockSize = MAX_INLINE_UNIFORM_BLOCK_SIZE,
      .maxPerStageDescriptorInlineUniformBlocks =
         MAX_INLINE_UNIFORM_BLOCK_DESCRIPTORS,
      .maxPerStageDescriptorUpdateAfterBindInlineUniformBlocks =
         MAX_INLINE_UNIFORM_BLOCK_DESCRIPTORS,
      .maxDescriptorSetInlineUniformBlocks =
         MAX_INLINE_UNIFORM_BLOCK_DESCRIPTORS,
      .maxDescriptorSetUpdateAfterBindInlineUniformBlocks =
         MAX_INLINE_UNIFORM_BLOCK_DESCRIPTORS,
      .maxInlineUniformTotalSize =
         MAX_INLINE_UNIFORM_BLOCK_DESCRIPTORS * MAX_INLINE_UNIFORM_BLOCK_SIZE,
      .integerDotProduct8BitUnsignedAccelerated = false,
      .integerDotProduct8BitSignedAccelerated = false,
      .integerDotProduct8BitMixedSignednessAccelerated = false,
      .integerDotProduct4x8BitPackedUnsignedAccelerated = PAN_ARCH >= 9,
      .integerDotProduct4x8BitPackedSignedAccelerated = PAN_ARCH >= 9,
      .integerDotProduct16BitUnsignedAccelerated = false,
      .integerDotProduct16BitSignedAccelerated = false,
      .integerDotProduct16BitMixedSignednessAccelerated = false,
      .integerDotProduct32BitUnsignedAccelerated = false,
      .integerDotProduct32BitSignedAccelerated = false,
      .integerDotProduct32BitMixedSignednessAccelerated = false,
      .integerDotProduct64BitUnsignedAccelerated = false,
      .integerDotProduct64BitSignedAccelerated = false,
      .integerDotProduct64BitMixedSignednessAccelerated = false,
      .integerDotProductAccumulatingSaturating8BitUnsignedAccelerated = false,
      .integerDotProductAccumulatingSaturating8BitSignedAccelerated = false,
      .integerDotProductAccumulatingSaturating8BitMixedSignednessAccelerated = false,
      .integerDotProductAccumulatingSaturating4x8BitPackedUnsignedAccelerated = PAN_ARCH >= 9,
      .integerDotProductAccumulatingSaturating4x8BitPackedSignedAccelerated = PAN_ARCH >= 9,
      .integerDotProductAccumulatingSaturating4x8BitPackedMixedSignednessAccelerated = false,
      .integerDotProductAccumulatingSaturating16BitUnsignedAccelerated = false,
      .integerDotProductAccumulatingSaturating16BitSignedAccelerated = false,
      .integerDotProductAccumulatingSaturating16BitMixedSignednessAccelerated = false,
      .integerDotProductAccumulatingSaturating32BitUnsignedAccelerated = false,
      .integerDotProductAccumulatingSaturating32BitSignedAccelerated = false,
      .integerDotProductAccumulatingSaturating32BitMixedSignednessAccelerated = false,
      .integerDotProductAccumulatingSaturating64BitUnsignedAccelerated = false,
      .integerDotProductAccumulatingSaturating64BitSignedAccelerated = false,
      .integerDotProductAccumulatingSaturating64BitMixedSignednessAccelerated = false,
      .storageTexelBufferOffsetAlignmentBytes = 16,
      .storageTexelBufferOffsetSingleTexelAlignment = true,
      .uniformTexelBufferOffsetAlignmentBytes = 4,
      .uniformTexelBufferOffsetSingleTexelAlignment = true,
      .maxBufferSize = panvk_get_max_buffer_size(device),

      /* Vulkan 1.4 properties */
      .lineSubPixelPrecisionBits = 8,
      /* We will have to restrict this a bit for multiview */
      .maxVertexAttribDivisor = UINT32_MAX,
      .supportsNonZeroFirstInstance = true,
      .maxPushDescriptors = MAX_PUSH_DESCS,
      .dynamicRenderingLocalReadDepthStencilAttachments = true,
      .dynamicRenderingLocalReadMultisampledAttachments = true,
      .earlyFragmentMultisampleCoverageAfterSampleCounting = true,
      .earlyFragmentSampleMaskTestBeforeSampleCounting = true,
      .depthStencilSwizzleOneSupport = true,
      .polygonModePointSize = false,
      .nonStrictSinglePixelWideLinesUseParallelogram = false,
      .nonStrictWideLinesUseParallelogram = false,
      .blockTexelViewCompatibleMultipleLayers = true,
      .maxCombinedImageSamplerDescriptorCount = 1,
      /* We don't implement VK_KHR_fragment_shading_rate */
      .fragmentShadingRateClampCombinerInputs = false,
      .defaultRobustnessStorageBuffers =
         VK_PIPELINE_ROBUSTNESS_BUFFER_BEHAVIOR_ROBUST_BUFFER_ACCESS_EXT,
      .defaultRobustnessUniformBuffers =
         VK_PIPELINE_ROBUSTNESS_BUFFER_BEHAVIOR_ROBUST_BUFFER_ACCESS_EXT,
      .defaultRobustnessVertexInputs =
         VK_PIPELINE_ROBUSTNESS_BUFFER_BEHAVIOR_ROBUST_BUFFER_ACCESS_EXT,
      .defaultRobustnessImages =
         VK_PIPELINE_ROBUSTNESS_IMAGE_BEHAVIOR_ROBUST_IMAGE_ACCESS_EXT,
      .identicalMemoryTypeRequirements = true,

      /* VK_KHR_pipeline_binary */
      .pipelineBinaryInternalCache = has_disk_cache,
      .pipelineBinaryInternalCacheControl = has_disk_cache,
      .pipelineBinaryPrefersInternalCache = has_disk_cache,
      .pipelineBinaryPrecompiledInternalCache = has_disk_cache,
      .pipelineBinaryCompressedData = false,

      /* VK_KHR_compute_shader_derivatives */
      .meshAndTaskShaderDerivatives = false,

      /* VK_KHR_cooperative_matrix */
      .cooperativeMatrixSupportedStages = VK_SHADER_STAGE_COMPUTE_BIT,

      /* VK_KHR_robustness2 */
      .robustStorageBufferAccessSizeAlignment = 4,
      .robustUniformBufferAccessSizeAlignment = 16,

      /* VK_EXT_shader_object */
      /* We do not currently support VK_EXT_shader_object but this is used
       * internally by vk_shader
       */
      .shaderBinaryVersion = 0,

      /* VK_KHR_maintenance7 */
      /* We don't implement VK_KHR_fragment_shading_rate */
      .robustFragmentShadingRateAttachmentAccess = false,
      .separateDepthStencilAttachmentAccess = false,
      .maxDescriptorSetTotalUniformBuffersDynamic = MAX_DYNAMIC_UNIFORM_BUFFERS,
      .maxDescriptorSetTotalStorageBuffersDynamic = MAX_DYNAMIC_STORAGE_BUFFERS,
      .maxDescriptorSetTotalBuffersDynamic = MAX_DYNAMIC_BUFFERS,
      .maxDescriptorSetUpdateAfterBindTotalUniformBuffersDynamic =
         PAN_ARCH >= 9 ? MAX_DYNAMIC_UNIFORM_BUFFERS : 0,
      .maxDescriptorSetUpdateAfterBindTotalStorageBuffersDynamic =
         PAN_ARCH >= 9 ? MAX_DYNAMIC_STORAGE_BUFFERS : 0,
      .maxDescriptorSetUpdateAfterBindTotalBuffersDynamic =
         PAN_ARCH >= 9 ? MAX_DYNAMIC_BUFFERS : 0,

      /* VK_KHR_maintenance9 */
      /* Sparse binding not supported yet. */
      .image2DViewOf3DSparse = false,
      .defaultVertexAttributeValue = VK_DEFAULT_VERTEX_ATTRIBUTE_VALUE_ZERO_ZERO_ZERO_ZERO_KHR,

      /* VK_EXT_conservative_rasterization */
      .primitiveOverestimationSize = 1.0f / 512.0f,
      .maxExtraPrimitiveOverestimationSize = 0.0f,
      .extraPrimitiveOverestimationSizeGranularity = 0.0f,
      .primitiveUnderestimation = false,
      .conservativePointAndLineRasterization = false,
      .degenerateTrianglesRasterized = PAN_ARCH >= 14,
      .degenerateLinesRasterized = false,
      .fullyCoveredFragmentShaderInputVariable = false,
      .conservativeRasterizationPostDepthCoverage = false,

      /* VK_EXT_custom_border_color */
      .maxCustomBorderColorSamplers = 32768,

      /* VK_EXT_graphics_pipeline_library */
      .graphicsPipelineLibraryFastLinking = true,
      .graphicsPipelineLibraryIndependentInterpolationDecoration = true,

      /* VK_EXT_nested_command_buffer */
      .maxCommandBufferNestingLevel = 5,

      /* VK_EXT_map_memory_placed */
      .minPlacedMemoryMapAlignment = os_page_size,

      /* VK_EXT_provoking_vertex */
      .provokingVertexModePerPipeline = false,
      .transformFeedbackPreservesTriangleFanProvokingVertex = false,

      /* VK_EXT_transform_feedback. The data sizes are the staging record,
       * PANVK_XFB_MAX_RECORD_DWORDS dwords per vertex. */
      .maxTransformFeedbackStreams = PAN_ARCH < 9 ? 4 : 1,
      .maxTransformFeedbackBuffers = 4,
      .maxTransformFeedbackBufferSize = UINT32_MAX,
      .maxTransformFeedbackStreamDataSize = PANVK_XFB_MAX_RECORD_DWORDS * 4,
      .maxTransformFeedbackBufferDataSize = PANVK_XFB_MAX_RECORD_DWORDS * 4,
      .maxTransformFeedbackBufferDataStride = 2048,
      .transformFeedbackQueries = false,
      .transformFeedbackStreamsLinesTriangles = false,
      .transformFeedbackRasterizationStreamSelect = false,
      .transformFeedbackDraw = false,

      /* VK_EXT_shader_tile_image */
      .shaderTileImageCoherentReadAccelerated = PAN_ARCH >= 9,
      .shaderTileImageReadSampleFromPixelRateInvocation = PAN_ARCH >= 9,
      .shaderTileImageReadFromHelperInvocation = PAN_ARCH >= 9,

      /* VK_ANDROID_native_buffer */
      .sharedImage = vk_android_get_front_buffer_usage() != 0,

      /* VK_ARM_shader_core_properties */
      .pixelRate = device->model->rates.pixel,
      .texelRate = device->model->rates.texel,
      .fmaRate = device->model->rates.fma,

      /* VK_ARM_shader_core_builtins */
      .shaderCoreMask = device->kmod.dev->props.shader_present,
      .shaderCoreCount = util_bitcount(device->kmod.dev->props.shader_present),
      .shaderWarpsPerCore = device->kmod.dev->props.max_threads_per_core /
                            (pan_subgroup_size(PAN_ARCH) * 2),

      /* VK_ARM_scheduling_controls */
      .schedulingControlsFlags =
         VK_PHYSICAL_DEVICE_SCHEDULING_CONTROLS_SHADER_CORE_COUNT_ARM,

      /* VK_KHR_copy_memory_indirect */
      .supportedQueues = VK_QUEUE_GRAPHICS_BIT | VK_QUEUE_COMPUTE_BIT,
   };

   snprintf(properties->deviceName, sizeof(properties->deviceName), "%s",
            (strlen(instance->drirc.debug.force_vk_devicename) > 0) ?
            instance->drirc.debug.force_vk_devicename : device->name);

   memcpy(properties->pipelineCacheUUID, device->cache_uuid, VK_UUID_SIZE);
   memcpy(properties->shaderBinaryUUID, device->cache_uuid, VK_UUID_SIZE);

   const struct {
      uint16_t vendor_id;
      uint32_t device_id;
      uint8_t pad[8];
   } dev_uuid = {
      .vendor_id = ARM_VENDOR_ID,
      .device_id = properties->deviceID,
   };

   STATIC_ASSERT(sizeof(dev_uuid) == VK_UUID_SIZE);
   memcpy(properties->deviceUUID, &dev_uuid, VK_UUID_SIZE);
   STATIC_ASSERT(sizeof(instance->driver_build_sha) >= VK_UUID_SIZE);
   memcpy(properties->driverUUID, instance->driver_build_sha, VK_UUID_SIZE);

   snprintf(properties->driverName, VK_MAX_DRIVER_NAME_SIZE, "panvk");
   snprintf(properties->driverInfo, VK_MAX_DRIVER_INFO_SIZE,
            "Mesa " PACKAGE_VERSION MESA_GIT_SHA1);

   /* VK_EXT_physical_device_drm */
   if (device->drm.primary_rdev) {
      properties->drmHasPrimary = true;
      properties->drmPrimaryMajor = major(device->drm.primary_rdev);
      properties->drmPrimaryMinor = minor(device->drm.primary_rdev);
   }
   if (device->drm.render_rdev) {
      properties->drmHasRender = true;
      properties->drmRenderMajor = major(device->drm.render_rdev);
      properties->drmRenderMinor = minor(device->drm.render_rdev);
   }

   /* VK_EXT_shader_module_identifier */
   STATIC_ASSERT(sizeof(vk_shaderModuleIdentifierAlgorithmUUID) ==
                 sizeof(properties->shaderModuleIdentifierAlgorithmUUID));
   memcpy(properties->shaderModuleIdentifierAlgorithmUUID,
          vk_shaderModuleIdentifierAlgorithmUUID,
          sizeof(properties->shaderModuleIdentifierAlgorithmUUID));

   /* VK_EXT_host_image_copy */
   /* We don't use image layouts, advertise all of them */
   static VkImageLayout supported_host_copy_layouts[] = {
      VK_IMAGE_LAYOUT_GENERAL,
      VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL,
      VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL,
      VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL,
      VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL,
      VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,
      VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
      VK_IMAGE_LAYOUT_PREINITIALIZED,
      VK_IMAGE_LAYOUT_ZERO_INITIALIZED_EXT,

      /* Only if vk1.1+ is supported */
#if PAN_ARCH >= 10
      /*  Vulkan 1.1 */
      VK_IMAGE_LAYOUT_DEPTH_READ_ONLY_STENCIL_ATTACHMENT_OPTIMAL,
      VK_IMAGE_LAYOUT_DEPTH_ATTACHMENT_STENCIL_READ_ONLY_OPTIMAL,

      /*  Vulkan 1.2 */
      VK_IMAGE_LAYOUT_DEPTH_ATTACHMENT_OPTIMAL,
      VK_IMAGE_LAYOUT_DEPTH_READ_ONLY_OPTIMAL,
      VK_IMAGE_LAYOUT_STENCIL_ATTACHMENT_OPTIMAL,
      VK_IMAGE_LAYOUT_STENCIL_READ_ONLY_OPTIMAL,

      /* Vulkan 1.3 */
      VK_IMAGE_LAYOUT_READ_ONLY_OPTIMAL,
      VK_IMAGE_LAYOUT_ATTACHMENT_OPTIMAL,

      /* Vulkan 1.4 */
      VK_IMAGE_LAYOUT_RENDERING_LOCAL_READ,

#endif

      /* VK_EXT_attachment_feedback_loop_layout */
      VK_IMAGE_LAYOUT_ATTACHMENT_FEEDBACK_LOOP_OPTIMAL_EXT,
   };
   properties->pCopySrcLayouts = supported_host_copy_layouts;
   properties->copySrcLayoutCount = ARRAY_SIZE(supported_host_copy_layouts);
   properties->pCopyDstLayouts = supported_host_copy_layouts;
   properties->copyDstLayoutCount = ARRAY_SIZE(supported_host_copy_layouts);
   /* All HW has the same tiling layout, key off build hash only */
   STATIC_ASSERT(sizeof(instance->driver_build_sha) >= VK_UUID_SIZE);
   memcpy(properties->optimalTilingLayoutUUID, instance->driver_build_sha,
          VK_UUID_SIZE);

   if (PANVK_DEBUG(STARTUP)) {
      mesa_logi("%s (%s) %s", properties->driverName, properties->deviceName,
                properties->driverInfo);
   }
}
