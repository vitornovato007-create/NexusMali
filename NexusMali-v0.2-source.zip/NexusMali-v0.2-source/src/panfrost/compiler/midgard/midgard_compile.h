/*
 * Copyright (C) 2018-2019 Alyssa Rosenzweig
 * Copyright (C) 2019-2020 Collabora, Ltd.
 * SPDX-License-Identifier: MIT
 */

#ifndef __MIDGARD_H_
#define __MIDGARD_H_

#include "compiler/nir/nir.h"
#include "panfrost/compiler/pan_compiler.h"
#include "panfrost/compiler/pan_nir.h"
#include "util/u_dynarray.h"

void midgard_preprocess_nir(nir_shader *nir, uint64_t gpu_id);
void midgard_postprocess_nir(nir_shader *nir, uint64_t gpu_id);
void midgard_lower_texture_nir(nir_shader *nir, uint64_t gpu_id);

bool midgard_will_dump_shaders(void);

void midgard_compile_shader_nir(nir_shader *nir,
                                const struct pan_compile_inputs *inputs,
                                struct util_dynarray *binary,
                                struct pan_shader_info *info);

uint32_t midgard_get_compiler_flags(void);

/* NIR options are shared between the standalone compiler and the online
 * compiler. Defining it here is the simplest, though maybe not the Right
 * solution. */

static const nir_shader_compiler_options midgard_nir_options = {
   .lower_fdiv = true,
   .lower_flrp16 = true,
   .lower_flrp32 = true,
   .lower_flrp64 = true,
   .lower_fpow = true,
   .lower_fmod = true,
   .lower_bitfield_extract8 = true,
   .lower_bitfield_extract16 = true,
   .lower_bitfield_extract = true,
   .lower_bitfield_insert = true,
   .lower_bitfield_reverse = true,
   .lower_bit_count = true,
   .lower_ifind_msb = true,
   .lower_find_lsb = true,
   .lower_uadd_carry = true,
   .lower_usub_borrow = true,
   .lower_ineg = true,
   .lower_fisnormal = true,
   .lower_scmp = true,
   .lower_isign = true,

   /* TODO: We have native ops to help here, which we'll want to look into
    * eventually */
   .lower_fsign = true,

   .lower_fdph = true,
   .lower_ffract = true,
   .lower_pack_half_2x16 = true,
   .lower_pack_unorm_2x16 = true,
   .lower_pack_snorm_2x16 = true,
   .lower_pack_unorm_4x8 = true,
   .lower_pack_snorm_4x8 = true,
   .lower_pack_64_2x32_split = true,
   .lower_unpack_half_2x16 = true,
   .lower_unpack_unorm_2x16 = true,
   .lower_unpack_snorm_2x16 = true,
   .lower_unpack_unorm_4x8 = true,
   .lower_unpack_snorm_4x8 = true,
   .lower_unpack_64_2x32_split = true,
   .lower_pack_split = true,
   .lower_extract_byte = true,
   .lower_extract_word = true,
   .lower_insert_byte = true,
   .lower_insert_word = true,
   .lower_cs_local_index_to_id = true,
   .has_cs_global_id = true,
   .lower_hadd = true,
   .has_fsub = true,
   .has_isub = true,
   .max_unroll_iterations = 32,
   .lower_uniforms_to_ubo = true,
   .force_indirect_unrolling_sampler = true,
   .force_indirect_unrolling =
      (nir_var_shader_in | nir_var_shader_out | nir_var_function_temp),
   .lower_int64_options = nir_lower_imul_2x32_64,
   .lower_doubles_options = nir_lower_dmod,
   .support_indirect_inputs = 0 /* TODO support indirect varyings */,
   .max_samples = 16,
   .lower_mediump_io = pan_nir_lower_mediump_io,
};

#endif
