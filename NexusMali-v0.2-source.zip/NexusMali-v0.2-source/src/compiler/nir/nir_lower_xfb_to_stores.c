/*
 * Copyright (C) 2022 Collabora Ltd.
 * SPDX-License-Identifier: MIT
 */

#include "nir.h"
#include "nir_builder.h"

/*
 * Software transform feedback: lower store_output intrinsics that carry
 * io_xfb information (attached by nir_io_add_intrinsic_xfb_info) into
 * store_global writes at
 *
 *    xfb_address(buffer) + (instance_id * num_vertices + raw_vertex_id)
 *                          * stride + offset
 *
 * The driver provides the xfb_address and num_vertices system values.
 * load_vertex_id is rewritten to raw_vertex_id + raw_vertex_offset since
 * transform feedback programs consume the zero-based hardware vertex ID.
 *
 * options->address_format selects the format of the store_global address -
 * a plain 32-bit or 64-bit global. When options->keep_outputs is false, the
 * store_output is removed
 * once its captures are emitted - for shader variants that run as a separate
 * capture-only job. Drivers that rasterize and capture in the same draw keep
 * the outputs.
 */

static void
lower_xfb_output(nir_builder *b, nir_intrinsic_instr *intr,
                 unsigned start_component, unsigned num_components,
                 unsigned buffer, unsigned offset_words,
                 nir_address_format address_format)
{
   unsigned address_bit_size = nir_address_format_bit_size(address_format);

   assert(buffer < MAX_XFB_BUFFERS);

   /* Transform feedback info in units of words, convert to bytes. */
   uint16_t stride = b->shader->info.xfb_stride[buffer] * 4;
   assert(stride != 0);

   uint16_t offset = offset_words * 4;

   nir_def *index = nir_iadd(
      b, nir_imul(b, nir_load_instance_id(b), nir_load_num_vertices(b)),
      nir_load_raw_vertex_id(b));

   BITSET_SET(b->shader->info.system_values_read,
              SYSTEM_VALUE_VERTEX_ID_ZERO_BASE);
   BITSET_SET(b->shader->info.system_values_read, SYSTEM_VALUE_INSTANCE_ID);

   nir_def *buf = nir_load_xfb_address(b, address_bit_size, .base = buffer);
   nir_def *word_offset = nir_iadd_imm(b, nir_imul_imm(b, index, stride),
                                       offset);
   nir_def *addr = nir_iadd(b, buf, nir_u2uN(b, word_offset, address_bit_size));

   nir_def *src = intr->src[0].ssa;
   nir_component_mask_t mask = nir_component_mask(num_components);
   mask = (mask << start_component) >> nir_intrinsic_component(intr);
   nir_def *value = nir_channels(b, src, mask);
   nir_store_global(b, value, addr);
}

static bool
lower_xfb(nir_builder *b, nir_intrinsic_instr *intr, void *data)
{
   const nir_lower_xfb_to_stores_options *options = data;

   /* In transform feedback programs, vertex ID becomes zero-based, so apply
    * that lowering even on Valhall.
    */
   if (intr->intrinsic == nir_intrinsic_load_vertex_id) {
      b->cursor = nir_instr_remove(&intr->instr);

      nir_def *repl = nir_iadd(b, nir_load_raw_vertex_id(b),
                               nir_load_raw_vertex_offset(b));

      nir_def_rewrite_uses(&intr->def, repl);
      return true;
   }

   if (intr->intrinsic != nir_intrinsic_store_output)
      return false;

   bool progress = false;

   b->cursor = nir_before_instr(&intr->instr);

   nir_io_xfb xfb = nir_intrinsic_io_xfb(intr);
   for (unsigned i = 0; i < 4; ++i) {
      if (!xfb.out[i].num_components)
         continue;

      lower_xfb_output(b, intr, i, xfb.out[i].num_components,
                        xfb.out[i].buffer, xfb.out[i].offset,
                        options->address_format);
      progress = true;
   }

   if (!options->keep_outputs)
      nir_instr_remove(&intr->instr);

   return progress;
}

bool
nir_lower_xfb_to_stores(nir_shader *nir, const nir_lower_xfb_to_stores_options *options)
{
   assert(options->address_format == nir_address_format_32bit_global ||
          options->address_format == nir_address_format_64bit_global);

   return nir_shader_intrinsics_pass(
      nir, lower_xfb, nir_metadata_control_flow, (void *)options);
}
