/*
 * Copyright © 2014 Connor Abbott
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the next
 * paragraph) shall be included in all copies or substantial portions of the
 * Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Authors:
 *    Connor Abbott (cwabbott0@gmail.com)
 *
 */

#ifndef NIR_CONSTANT_EXPRESSIONS_H
#define NIR_CONSTANT_EXPRESSIONS_H

#include "nir_defines.h"
#include "nir_opcodes.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Evaluates the NIR opcode for the given source constant values.
 *
 * If @poison is non-NULL, it will containe the nir_component_mask of output
 * channels that invoked undefined behavior (define not used here, to avoid
 * pulling in all of nir.h).
 */
void nir_eval_const_opcode(nir_op op, nir_const_value *dest, uint16_t *poison,
                           unsigned num_components, unsigned bit_size,
                           nir_const_value **src,
                           unsigned float_controls_execution_mode);

#ifdef __cplusplus
}
#endif

#endif /* NIR_CONSTANT_EXPRESSIONS_H */
