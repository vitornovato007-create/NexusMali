/*
 * Copyright © 2018, Google Inc.
 *
 * based on the anv driver which is:
 * Copyright © 2017 Intel Corporation
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the next
 * paragraph) shall be included in all copies or substantial portions of the
 * Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
#ifndef VK_DEBUG_REPORT_H
#define VK_DEBUG_REPORT_H

#include "vk_object.h"

#include "util/simple_mtx.h"
#include "util/list.h"

#ifdef __cplusplus
extern "C" {
#endif

struct vk_debug_report {
   mtx_t callbacks_mutex;
   struct list_head callbacks;
};

void
vk_debug_report(struct vk_debug_report *debug_report,
                VkDebugReportFlagsEXT flags,
                const struct vk_object_base *object,
                size_t location,
                int32_t messageCode,
                const char* pLayerPrefix,
                const char *pMessage);

#ifdef __cplusplus
}
#endif

#endif /* VK_DEBUG_REPORT_H */
