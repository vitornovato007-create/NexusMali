
#!/usr/bin/env bash
# NexusMali v0.2 - compilação Linux host + Android ARM64.
# Requer: NDK Android API 31, LLVM/Clang 20, Meson, Ninja e glslang.
# Uso: ./build.sh [caminho-do-NDK]

set -Eeuo pipefail

cd "$(dirname "$(readlink -f "$0")")"

die() {
    echo "ERRO: $*" >&2
    exit 1
}

NDK="${1:-${ANDROID_NDK:-${ANDROID_NDK_HOME:-${ANDROID_NDK_ROOT:-}}}}"
[ -n "$NDK" ] || die "NDK não definido."
[ -d "$NDK" ] || die "Diretório NDK inexistente: $NDK"

HOST="linux-x86_64"
BIN="$NDK/toolchains/llvm/prebuilt/$HOST/bin"
API="${ANDROID_API:-31}"

[ -x "$BIN/aarch64-linux-android${API}-clang" ] ||
    die "Compilador Android API ${API} não encontrado em $BIN"

# Prioriza explicitamente as ferramentas nativas do Ubuntu.
# O NDK será usado por caminho absoluto somente na etapa Android.
HOST_LLVM="/usr/lib/llvm-20/bin"
HOST_PATH="$HOME/.local/bin:$HOST_LLVM:/usr/bin:/bin"

for tool in meson ninja python3 pkg-config glslangValidator; do
    command -v "$tool" >/dev/null 2>&1 ||
        die "Ferramenta ausente: $tool"
done

[ -x "$HOST_LLVM/llvm-config" ] ||
    die "LLVM 20 não encontrado em $HOST_LLVM"
[ -x /usr/bin/clang-20 ] ||
    die "clang-20 não instalado"
[ -x /usr/bin/clang++-20 ] ||
    die "clang++-20 não instalado"

export PATH="$HOST_PATH"
export LC_ALL=C.UTF-8

echo "=========================================="
echo "FERRAMENTAS HOST"
echo "=========================================="
echo "LLVM: $("$HOST_LLVM/llvm-config" --version)"
echo "Clang: $(/usr/bin/clang-20 --version | head -n 1)"
echo "Meson: $(meson --version)"
echo "Ninja: $(ninja --version)"
echo "NDK: $NDK"
echo "API Android: $API"

# Opcional: CLEAN_BUILD=1 força uma compilação limpa.
if [ "${CLEAN_BUILD:-0}" = "1" ]; then
    rm -rf build-host build-android dist
fi

# ------------------------------------------------------------
# ETAPA 1: ferramentas executadas no Linux do GitHub Actions.
# ------------------------------------------------------------

HOSTB="build-host"

if [ ! -f "$HOSTB/build.ninja" ]; then
    rm -rf "$HOSTB"

    env \
        PATH="$HOST_PATH" \
        CC=/usr/bin/clang-20 \
        CXX=/usr/bin/clang++-20 \
        LLVM_CONFIG="$HOST_LLVM/llvm-config" \
        meson setup "$HOSTB" \
            -Dbuildtype=debugoptimized \
            -Dmesa-clc=enabled \
            -Dprecomp-compiler=enabled \
            -Dvulkan-drivers=panfrost \
            -Dgallium-drivers= \
            -Dplatforms= \
            -Dllvm=enabled \
            -Dgles1=disabled \
            -Dgles2=disabled \
            -Degl=disabled \
            -Dglx=disabled \
            -Dgbm=disabled \
            -Dtools= \
            -Dvideo-codecs= \
            -Dallow-fallback-for=libdrm \
            --force-fallback-for=libdrm,expat,zlib \
            -Dlibdrm:default_library=static
fi

env PATH="$HOST_PATH" ninja -C "$HOSTB" \
    src/compiler/clc/mesa_clc \
    src/compiler/spirv/vtn_bindgen2 \
    src/panfrost/clc/panfrost_compile

mkdir -p "$HOSTB/bin"

cp \
    "$HOSTB/src/compiler/clc/mesa_clc" \
    "$HOSTB/src/compiler/spirv/vtn_bindgen2" \
    "$HOSTB/src/panfrost/clc/panfrost_compile" \
    "$HOSTB/bin/"

chmod +x \
    "$HOSTB/bin/mesa_clc" \
    "$HOSTB/bin/vtn_bindgen2" \
    "$HOSTB/bin/panfrost_compile"

# ------------------------------------------------------------
# ETAPA 2: driver Android ARM64, compilado com o NDK.
# ------------------------------------------------------------

BUILD="${BUILD_DIR:-build-android}"
mkdir -p "$BUILD" "$BUILD/pkgconfig-empty"

cat > "$BUILD/cross.ini" <<EOF
[binaries]
c = '$BIN/aarch64-linux-android${API}-clang'
cpp = '$BIN/aarch64-linux-android${API}-clang++'
ar = '$BIN/llvm-ar'
strip = '$BIN/llvm-strip'
pkg-config = '/usr/bin/pkg-config'

[properties]
pkg_config_libdir = ['$PWD/$BUILD/pkgconfig-empty']
cpp_link_args = ['-static-libstdc++']

[host_machine]
system = 'android'
cpu_family = 'aarch64'
cpu = 'aarch64'
endian = 'little'
EOF

if [ ! -f "$BUILD/build.ninja" ]; then
    rm -rf "$BUILD"
    mkdir -p "$BUILD/pkgconfig-empty"

    # Recria o cross-file depois de limpar o diretório.
    cat > "$BUILD/cross.ini" <<EOF
[binaries]
c = '$BIN/aarch64-linux-android${API}-clang'
cpp = '$BIN/aarch64-linux-android${API}-clang++'
ar = '$BIN/llvm-ar'
strip = '$BIN/llvm-strip'
pkg-config = '/usr/bin/pkg-config'

[properties]
pkg_config_libdir = ['$PWD/$BUILD/pkgconfig-empty']
cpp_link_args = ['-static-libstdc++']

[host_machine]
system = 'android'
cpu_family = 'aarch64'
cpu = 'aarch64'
endian = 'little'
EOF

    env PATH="$PWD/$HOSTB/bin:$HOST_PATH" \
        meson setup "$BUILD" \
            --cross-file "$BUILD/cross.ini" \
            -Dbuildtype=debugoptimized \
            -Db_ndebug=true \
            -Dplatforms=android \
            -Dplatform-sdk-version="$API" \
            -Dandroid-stub=true \
            -Dandroid-strict=false \
            -Dandroid-libbacktrace=disabled \
            -Dvulkan-drivers=panfrost \
            -Dgallium-drivers= \
            -Dtools= \
            -Dvideo-codecs= \
            -Dmesa-clc=system \
            -Dprecomp-compiler=system \
            -Dllvm=disabled \
            -Dzstd=disabled \
            -Dlmsensors=disabled \
            -Dperfetto=false \
            -Dglx=disabled \
            -Dgbm=disabled \
            -Degl=disabled \
            -Dgles1=disabled \
            -Dgles2=disabled \
            -Dallow-fallback-for=libdrm,perfetto \
            --force-fallback-for=expat,libdrm,zlib \
            -Dlibdrm:default_library=static \
            -Dexpat:default_library=static \
            -Dzlib:default_library=static
fi

env PATH="$PWD/$HOSTB/bin:$HOST_PATH" \
    ninja -C "$BUILD" src/panfrost/vulkan/libvulkan_panfrost.so

# ------------------------------------------------------------
# EMPACOTAMENTO E VERIFICAÇÕES
# ------------------------------------------------------------

DRIVER="$BUILD/src/panfrost/vulkan/libvulkan_panfrost.so"
[ -s "$DRIVER" ] || die "A biblioteca Vulkan não foi gerada."

mkdir -p dist
rm -f dist/NexusMali-v0.2-android-arm64.zip

"$BIN/llvm-strip" \
    -o "$BUILD/libvulkan_panfrost-stripped.so" \
    "$DRIVER"

python3 android/package.py \
    "$BUILD/libvulkan_panfrost-stripped.so" dist

[ -n "$(find dist -maxdepth 1 -type f -print -quit)" ] ||
    die "O empacotamento não gerou arquivos em dist/."

echo
echo "=========================================="
echo "BUILD FINALIZADO"
echo "=========================================="
echo "Biblioteca compilada: $DRIVER"
echo "Arquivos de pacote:"
find dist -maxdepth 1 -type f -printf '%f (%s bytes)\n' | sort