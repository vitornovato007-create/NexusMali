#!/usr/bin/env bash
# NexusMali v0.2.1 experimental - Linux host + Android ARM64.
# Raiz esperada após extrair NexusMali-v0.2.1-source.zip:
# NexusMali-v0.2.1-source/{build.sh, meson.build, meson.options, android/package.py, ...}
# Uso: ./build.sh [caminho-do-NDK]
# Build limpo: CLEAN_BUILD=1 ./build.sh /caminho/para/android-ndk

set -Eeuo pipefail
cd "$(dirname "$(readlink -f "$0")")"

die() {
    echo "ERRO: $*" >&2
    exit 1
}

# Não procura uma segunda raiz: o build.sh deve estar ao lado do meson.build.
[ -f meson.build ] || die "meson.build não está ao lado deste build.sh. Raiz atual: $PWD"
[ -f meson.options ] || die "meson.options não encontrado em $PWD"
[ -f android/package.py ] || die "android/package.py não encontrado em $PWD"

NDK="${1:-${ANDROID_NDK:-${ANDROID_NDK_HOME:-${ANDROID_NDK_ROOT:-}}}}"
[ -n "$NDK" ] || die "NDK não definido. Passe o caminho do NDK como argumento ou defina ANDROID_NDK."
[ -d "$NDK" ] || die "Diretório NDK inexistente: $NDK"

HOST="linux-x86_64"
BIN="$NDK/toolchains/llvm/prebuilt/$HOST/bin"
API="${ANDROID_API:-31}"

[ -x "$BIN/aarch64-linux-android${API}-clang" ] || die "Compilador Android API ${API} não encontrado em $BIN"
[ -x "$BIN/llvm-strip" ] || die "llvm-strip não encontrado em $BIN"

HOST_LLVM="/usr/lib/llvm-20/bin"
HOST_PATH="$HOME/.local/bin:$HOST_LLVM:/usr/bin:/bin"

for tool in meson ninja python3 pkg-config glslangValidator; do
    command -v "$tool" >/dev/null 2>&1 || die "Ferramenta ausente: $tool"
done
[ -x "$HOST_LLVM/llvm-config" ] || die "LLVM 20 não encontrado em $HOST_LLVM"
[ -x /usr/bin/clang-20 ] || die "clang-20 não instalado"
[ -x /usr/bin/clang++-20 ] || die "clang++-20 não instalado"

export PATH="$HOST_PATH"
export LC_ALL=C.UTF-8

HOSTB="build-host"
BUILD="${BUILD_DIR:-build-android-release}"
DIST="dist-v0.2.1-experimental"

echo "=========================================="
echo "NEXUSMALI v0.2.1 EXPERIMENTAL"
echo "=========================================="
echo "Raiz: $PWD"
echo "LLVM: $("$HOST_LLVM/llvm-config" --version)"
echo "Clang: $(/usr/bin/clang-20 --version | head -n 1)"
echo "Meson: $(meson --version)"
echo "Ninja: $(ninja --version)"
echo "NDK: $NDK"
echo "API Android: $API"

if [ "${CLEAN_BUILD:-0}" = "1" ]; then
    echo "Limpando diretórios de compilação e distribuição..."
    rm -rf "$HOSTB" "$BUILD" "$DIST"
fi

# ETAPA 1: ferramentas host.
if [ ! -f "$HOSTB/build.ninja" ]; then
    rm -rf "$HOSTB"
    env PATH="$HOST_PATH" \
        CC=/usr/bin/clang-20 \
        CXX=/usr/bin/clang++-20 \
        LLVM_CONFIG="$HOST_LLVM/llvm-config" \
        meson setup "$HOSTB" \
            -Dbuildtype=debugoptimized \
            -Dmesa-clc=enabled \
            -Dprecomp-compiler=enabled \
            -Dvulkan-drivers=panfrost \
            -Dgallium-drivers= \
            -Dplatforms= \
            -Dllvm=enabled \
            -Dgles1=disabled \
            -Dgles2=disabled \
            -Degl=disabled \
            -Dglx=disabled \
            -Dgbm=disabled \
            -Dtools= \
            -Dvideo-codecs= \
            -Dallow-fallback-for=libdrm \
            --force-fallback-for=libdrm,expat,zlib \
            -Dlibdrm:default_library=static
fi

env PATH="$HOST_PATH" ninja -C "$HOSTB" \
    src/compiler/clc/mesa_clc \
    src/compiler/spirv/vtn_bindgen2 \
    src/panfrost/clc/panfrost_compile

mkdir -p "$HOSTB/bin"
cp \
    "$HOSTB/src/compiler/clc/mesa_clc" \
    "$HOSTB/src/compiler/spirv/vtn_bindgen2" \
    "$HOSTB/src/panfrost/clc/panfrost_compile" \
    "$HOSTB/bin/"
chmod +x "$HOSTB/bin/mesa_clc" "$HOSTB/bin/vtn_bindgen2" "$HOSTB/bin/panfrost_compile"

# ETAPA 2: driver Android ARM64.
mkdir -p "$BUILD" "$BUILD/pkgconfig-empty"

write_cross_file() {
    cat > "$BUILD/cross.ini" <<EOF
[binaries]
c = '$BIN/aarch64-linux-android${API}-clang'
cpp = '$BIN/aarch64-linux-android${API}-clang++'
ar = '$BIN/llvm-ar'
strip = '$BIN/llvm-strip'
pkg-config = '/usr/bin/pkg-config'

[properties]
pkg_config_libdir = ['$PWD/$BUILD/pkgconfig-empty']
cpp_link_args = ['-static-libstdc++']

[host_machine]
system = 'android'
cpu_family = 'aarch64'
cpu = 'aarch64'
endian = 'little'
EOF
}

if [ ! -f "$BUILD/build.ninja" ]; then
    rm -rf "$BUILD"
    mkdir -p "$BUILD/pkgconfig-empty"
    write_cross_file

    env PATH="$PWD/$HOSTB/bin:$HOST_PATH" \
        meson setup "$BUILD" \
            --cross-file "$BUILD/cross.ini" \
            -Dbuildtype=release \
            -Db_ndebug=true \
            -Dplatforms=android \
            -Dplatform-sdk-version="$API" \
            -Dandroid-stub=true \
            -Dandroid-strict=false \
            -Dandroid-libbacktrace=disabled \
            -Dvulkan-drivers=panfrost \
            -Dgallium-drivers= \
            -Dtools= \
            -Dvideo-codecs= \
            -Dmesa-clc=system \
            -Dprecomp-compiler=system \
            -Dllvm=disabled \
            -Dzstd=disabled \
            -Dlmsensors=disabled \
            -Dperfetto=false \
            -Dglx=disabled \
            -Dgbm=disabled \
            -Degl=disabled \
            -Dgles1=disabled \
            -Dgles2=disabled \
            -Dallow-fallback-for=libdrm,perfetto \
            --force-fallback-for=expat,libdrm,zlib \
            -Dlibdrm:default_library=static \
            -Dexpat:default_library=static \
            -Dzlib:default_library=static
else
    write_cross_file
fi

env PATH="$PWD/$HOSTB/bin:$HOST_PATH" \
    ninja -C "$BUILD" src/panfrost/vulkan/libvulkan_panfrost.so

# ETAPA 3: biblioteca e pacote.
DRIVER="$BUILD/src/panfrost/vulkan/libvulkan_panfrost.so"
STRIPPED="$BUILD/libvulkan_panfrost-stripped.so"
WORKFLOW_DRIVER="$BUILD/libvulkan_panfrost.so"

[ -s "$DRIVER" ] || die "Biblioteca Vulkan original ausente: $DRIVER"
"$BIN/llvm-strip" -o "$STRIPPED" "$DRIVER"
[ -s "$STRIPPED" ] || die "Biblioteca stripped ausente: $STRIPPED"

# O workflow atual procura build-android-release/libvulkan_panfrost.so.
# Publica nesse caminho uma cópia stripped para evitar ambiguidade.
cp "$STRIPPED" "$WORKFLOW_DRIVER"
[ -s "$WORKFLOW_DRIVER" ] || die "Cópia compatível com o workflow não foi criada."

mkdir -p "$DIST"
rm -f "$DIST"/*
python3 android/package.py "$STRIPPED" "$DIST"
[ -n "$(find "$DIST" -maxdepth 1 -type f -print -quit)" ] || die "Empacotamento vazio: $DIST"

echo
echo "=========================================="
echo "BUILD FINALIZADO"
echo "=========================================="
echo "Raiz do projeto: $PWD"
echo "Biblioteca original: $DRIVER"
echo "Biblioteca stripped: $STRIPPED"
echo "Biblioteca que o build.yml pode empacotar: $WORKFLOW_DRIVER"
echo "Arquivos de pacote:"
find "$DIST" -maxdepth 1 -type f -printf '%f (%s bytes)\n' | sort
echo
file "$WORKFLOW_DRIVER"
readelf -h "$WORKFLOW_DRIVER" | grep -E 'Class:|Data:|Type:|Machine:'
